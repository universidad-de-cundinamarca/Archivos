<?php

$salida="";

if (isset($_POST['consulta'])) {
    include_once "../modelo/Admimodelo.php";
    include_once "../modelo/Conexion.php";
    $admimodelo=new Admimodelo();

    $salida.='	<div class="text-left" style="padding:10px;">
    <a href="index.php?accion=frutiadmi">				<i class="zmdi zmdi-long-arrow-left"></i>
             Catalogo</a>
    </div>';

if($_POST['consulta']=="uno"){


$tabla=$admimodelo->tablaadmi();


       $salida.= '
       
       <div class="mdl-grid">
       <div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--8-col-desktop mdl-cell--2-offset-desktop">
           <div class="full-width panel mdl-shadow--2dp">
               <div class="full-width panel-tittle bg-success text-center tittles">
                  Lista de Administradores
               </div>
               <div class="full-width panel-content">
                   <form action="#">
                       <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
                           <label class="mdl-button mdl-js-button mdl-button--icon" for="searchAdmin">
                               <i class="zmdi zmdi-search"></i>
                           </label>
                           <div class="mdl-textfield__expandable-holder">
                               <input class="mdl-textfield__input" type="text" id="searchAdmin">
                               <label class="mdl-textfield__label"></label>
                           </div>
                       </div>
                   </form> 
                   <div class="mdl-list">';


                   foreach ($tabla as $res) {
                      
                   
                    $nombre=$res['nombre1'];
                    $apellido=$res['apellido1'];
                    $apellido1=$res['apellido2'];
                    $ced=$res['cedula'];
                   $salida.="
                   <div class='mdl-list__item mdl-list__item--two-line'>
                   <span class='mdl-list__item-primary-content'>
                       <i class='zmdi zmdi-account mdl-list__item-avatar'></i>
                       <span>$nombre $apellido $apellido1</span>
                       <span class='mdl-list__item-sub-title'>$ced</span>
                   </span>
                   <a class='mdl-list__item-secondary-action' href='index.php?accion=actualizaradmi&id=$ced'><i class='zmdi zmdi-more'></i></a>
               </div>";
                   
                   }
                       
                    $salida.=  '
                   </div>
               </div>
           </div>
       </div>
   </div>';
   
   
   
   

}

   
if($_POST['consulta']=="dos"){
    $tabla=$admimodelo->tablacomer();


    $salida.= '
    
    <div class="mdl-grid ">
    <div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--8-col-desktop mdl-cell--2-offset-desktop">
        <div class="full-width panel mdl-shadow--2dp ">
            <div class="full-width panel-tittle bg-success text-center tittles">
           Lista de Comerciantes
            </div>
            <div class="full-width panel-content cambia">
                <form action="#">
                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
                        <label class="mdl-button mdl-js-button mdl-button--icon" for="searchAdmin">
                            <i class="zmdi zmdi-search"></i>
                        </label>
                        <div class="mdl-textfield__expandable-holder">
                            <input class="mdl-textfield__input" type="text" id="searchAdmin">
                            <label class="mdl-textfield__label"></label>
                        </div>
                    </div>
                </form> 
                <div class="mdl-list">';


                foreach ($tabla as $res) {
                   
                
                 $nombre=$res['nombre1'];
                 $apellido=$res['apellido1'];
                 $apellido1=$res['apellido2'];
                 $ced=$res['cedula'];
                $salida.="
                <div class='mdl-list__item mdl-list__item--two-line'>
                <span class='mdl-list__item-primary-content'>
                    <i class='zmdi zmdi-account mdl-list__item-avatar'></i>
                    <span>$nombre $apellido $apellido1</span>
                    <span class='mdl-list__item-sub-title'>$ced</span>
                </span>
                <a class='mdl-list__item-secondary-action' href='index.php?accion=actualizaradmi&id=$ced'><i class='zmdi zmdi-more'></i></a>
                 </div>";
                
                }
                    
                 $salida.=  '
                </div>
            </div>
        </div>
    </div>
</div>';


}
if($_POST['consulta']=="tres"){
    $tabla=$admimodelo->tablafruti();


    $salida.= '
    
    <div class="mdl-grid">
    <div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--8-col-desktop mdl-cell--2-offset-desktop">
        <div class="full-width panel mdl-shadow--2dp">
            <div class="full-width panel-tittle bg-success text-center tittles">
                Lista de Fruticultores
            </div>
            <div class="full-width panel-content">
                <form action="#">
                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
                        <label class="mdl-button mdl-js-button mdl-button--icon" for="searchAdmin">
                            <i class="zmdi zmdi-search"></i>
                        </label>
                        <div class="mdl-textfield__expandable-holder">
                            <input class="mdl-textfield__input" type="text" id="searchAdmin">
                            <label class="mdl-textfield__label"></label>
                        </div>
                    </div>
                </form> 
                <div class="mdl-list">';


                foreach ($tabla as $res) {
                   
                
                 $nombre=$res['nombre1'];
                 $apellido=$res['apellido1'];
                 $apellido1=$res['apellido2'];
                 $ced=$res['cedula'];
                $salida.="
                <div class='mdl-list__item mdl-list__item--two-line'>
                <span class='mdl-list__item-primary-content'>
                    <i class='zmdi zmdi-account mdl-list__item-avatar'></i>
                    <span>$nombre $apellido $apellido1</span>
                    <span class='mdl-list__item-sub-title'>$ced</span>
                </span>
                <a class='mdl-list__item-secondary-action' href='index.php?accion=actualizaradmi&id=$ced'><i class='zmdi zmdi-more'></i></a>
            </div>";
                
                }
                    
                 $salida.=  '
                </div>
            </div>
        </div>
    </div>
</div>';


}



if($_POST['consulta']=="cuatro"){
    $tabla=$admimodelo->tablapro();


    $salida.= '
    
    <div class="mdl-grid">
    <div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--8-col-desktop mdl-cell--2-offset-desktop">
        <div class="full-width panel mdl-shadow--2dp">
            <div class="full-width panel-tittle bg-success text-center tittles">
                Lista de Frutas
            </div>
            <div class="full-width panel-content">
                <form action="#">
                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
                        <label class="mdl-button mdl-js-button mdl-button--icon" for="searchAdmin">
                            <i class="zmdi zmdi-search"></i>
                        </label>
                        <div class="mdl-textfield__expandable-holder">
                            <input class="mdl-textfield__input" type="text" id="searchAdmin">
                            <label class="mdl-textfield__label"></label>
                        </div>
                    </div>
                </form> 
                <div class="mdl-list">';


                foreach ($tabla as $res) {
                   
                
                 $nombre=$res['nombre'];
             
                 $id=$res['Id'];
                $salida.="
                <div class='mdl-list__item mdl-list__item--two-line '>
             
               <span class='mdl-list__item-primary-content'>
            
               <span>$nombre </span>
                   <span class='mdl-list__item-sub-title'>$id</span>
                  
               </span>

               
                <span>
                <img   src='vista/imagenes/$nombre.png' alt='product' class='img-responsive'>

                </span>

                <div style='padding:20px'>
                <a class='mdl-list__item-secondary-action' href='index.php?accion=actualizaradmi&id=$id'><i class='zmdi zmdi-more'></i></a>
          </div>
                </div>
           
              
            ";
                
                }
                    
                 $salida.=  '
                </div>
            </div>
        </div>
    </div>
</div>';

}
if($_POST['consulta']=="cinco"){

    $tablacoti=$admimodelo->tablacoti();
    $salida.='<div class="container" style="width:1000px;">

    <div class="full-width panel-tittle bg-success text-center tittles">
                Lista de Cotizaciones
            </div>
    <table class="table table-sm table-dark" >
    <thead>
      <tr>
        <th scope="col">N°</th>
        <th scope="col">Fruta</th>
        <th scope="col">Precio</th>
        <th scope="col">Valor Total</th>
        <th scope="col">Fruticultor</th>
        <th scope="col">Cliente</th>
      </tr>
    </thead>
    <tbody>';
foreach ($tablacoti as $tabla) {
    $id=$tabla['id_productocomerciante'];
    $nom=$tabla['nombre'];
    $precio=$tabla['precio'];
    $valor=$tabla['ofrecer']*$precio;
    $ven=$tabla['fruticultor'];
    $com=$tabla['comerciante'];

$salida.=" <tr>
<th scope='row'>$id</th>
<td>$nom</td>
<td>$precio</td>
<td>$valor</td>
<td>$ven</td>
<td>$com</td>
</tr>";
} 


$salida.='
     
    </tbody>
    </table>
    </div>
   ';
}

if($_POST['consulta']=="seis"){

    $tablapre=$admimodelo->tablapre();
    $salida.='<div class="container" style="width:1000px;">

    <div class="full-width panel-tittle bg-success text-center tittles">
                Lista de Cotizaciones
            </div>
    <table class="table table-sm table-dark" >
    <thead>
      <tr>
        <th scope="col">N°</th>
        <th scope="col">Fruta</th>
        <th scope="col">Precio</th>
        <th scope="col">Valor Total</th>
        <th scope="col">Fruticultor</th>
        <th scope="col">Cliente</th>
      </tr>
    </thead>
    <tbody>';
foreach ($tablapre as $tabla) {
    $id=$tabla['id_prevendidos'];
    $nom=$tabla['nombre'];
    $precio=$tabla['precio'];
    $valor=$tabla['cantidad']*$precio;
    $ven=$tabla['vendedor'];
    $com=$tabla['cliente'];

$salida.=" <tr>
<th scope='row'>$id</th>
<td>$nom</td>
<td>$precio</td>
<td>$valor</td>
<td>$ven</td>
<td>$com</td>
</tr>";
} 


$salida.='
     
    </tbody>
    </table>
    </div>
   ';
}


}

echo $salida;




?>