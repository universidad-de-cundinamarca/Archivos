<?php
class Fruticultor{

  private $tablaproducto;
  private $tablaproductoarriba;
  
    public function producto(){
        
     $producto=new Fruticultormodel();
     $this->tablaproducto=$producto->producto();
     return $this->tablaproducto;

   
    }
    public function Registrarproducto($fechaini,$fechafin,$precio,$cantidad,$descripcion,$fruticultor,$fruta,$estado){
        
        $producto=new Fruticultormodel();
       $res= $producto->Registrarproducto($fechaini,$fechafin,$precio,$cantidad,$descripcion,$fruticultor,$fruta,$estado);
        return $res;
       }
       public function Actualizarproducto($fechafin,$precio,$cantidad,$descripcion,$fruta,$estado,$id){
        
        $producto=new Fruticultormodel();
       $res= $producto->Actualizarproducto($fechafin,$precio,$cantidad,$descripcion,$fruta,$estado,$id);
        return $res;
       }
       public function Eliminarproducto($id){
        
        $producto=new Fruticultormodel();
       $res= $producto->Eliminarproducto($id);
        return $res;
       }


       public function productoarriba($ced){
        
        $producto=new Fruticultormodel();
        $this->tablaproductoarriba=$producto->productoarriba($ced);
        return $this->tablaproductoarriba;
   
      
       }
       public function productoarribacotizado($ced){
        
        $producto=new Fruticultormodel();
        $tablaproductoarribacotizado=$producto->productoarribacotizado($ced);
        return $tablaproductoarribacotizado;
   
      
       }
       public function productoarribacotizado1($ced){
        
        $producto=new Fruticultormodel();
        $tablaproductoarribacotizado=$producto->productoarribacotizado1($ced);
        return $tablaproductoarribacotizado;
   
      
       }
       public function productoarriba1(){
        
        $producto=new Fruticultormodel();
        $this->tablaproductoarriba=$producto->productoarriba1();
        return $this->tablaproductoarriba;
   
      
       }
       public function productoarribatodo($id){
        
        $producto=new Fruticultormodel();
        $this->tablaproductoarriba=$producto->productoarribatodo($id);
        return $this->tablaproductoarriba;
   
      
       }

}




?>