<?php

class Cotizar{
    public function recotizar($cliente,$producto,$fruti,$ofrece){

       
        if($cliente==$fruti){
            return -1;


        }else{
            $cotizarmodelo=new cotizarmodelo();

            $res=$cotizarmodelo->recotizar($cliente,$producto,$fruti,$ofrece);
                
        return $res;

        }
 
    }
    public function recotizar1($cliente,$producto,$fruti,$ofrece,$ofrecerqueda){
        if($cliente==$fruti){
            return -1;


        }else{
            $cotizarmodelo=new cotizarmodelo();
    
            $res=$cotizarmodelo->recotizar1($cliente,$producto,$fruti,$ofrece,$ofrecerqueda);
                
        return $res;
        }
      
        }
        public function cotizaciones($cliente){
            $cotizarmodelo=new cotizarmodelo();
        
            $tabla=$cotizarmodelo->cotizaciones($cliente);
                
        return $tabla;
            }
            public function comprados($cliente){
                $cotizarmodelo=new cotizarmodelo();
            
                $tabla=$cotizarmodelo->comprados($cliente);
                    
            return $tabla;
                }
            public function cancelarcoti($id,$ida,$can){
                $cotizarmodelo=new cotizarmodelo();
            
                $res=$cotizarmodelo->cancelarcoti($id,$ida,$can);
                    
            return $res;
                }
                public function cancelarco($id){
                    $cotizarmodelo=new cotizarmodelo();
                
                   $cotizarmodelo->cancelarco($id);
                        
               
                    }
                    public function cancelarco1($id){
                        $cotizarmodelo=new cotizarmodelo();
                    
                       $cotizarmodelo->cancelarco1($id);
                            
                   
                        }

                public function cancelarcotiin($id,$cant,$ida){
                    $cotizarmodelo=new cotizarmodelo();
                
                    $res=$cotizarmodelo->cancelarcotiin($id,$cant,$ida);
                        
                return $res;
                    }
                    public function cancelarcotiin1($id,$cant,$ida,$etd){
                        $cotizarmodelo=new cotizarmodelo();
                    
                        $res=$cotizarmodelo->cancelarcotiin1($id,$cant,$ida,$etd);
                            
                    return $res;
                        }
                        public function realizarcoti($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente){
                            $cotizarmodelo=new cotizarmodelo();
                            $res=$cotizarmodelo->campro($ida);
                            $cont=0;

                           foreach ($res as $key) {
                              $cont++;
                           }

                           if($cont==1){
                            $res=$cotizarmodelo->realizarcoti($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente);
                            
                           }else{
                             
                            $res=$cotizarmodelo->realizarcotiper($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente);
                            
                           }
                                
                        return $res;
                            }
                            public function realizarcoti1($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente){
                                $cotizarmodelo=new cotizarmodelo();

                                $res=$cotizarmodelo->campro($ida);
                                $cont=0;

                                foreach ($res as $key) {
                                   $cont++;
                                }
                                if($cont==1){
                                 $res=$cotizarmodelo->realizarcotiper2($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente);
                                }else{
                                    $res=$cotizarmodelo->realizarcoti1($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente);
                                }
                                    
                           return $res;
                                }
    }

?>