<?php

class Controlador{
private $nombre;
private $usuario;
private $nombre1;


public function __construct(){
    
}

public function verPagina($ruta){
    require_once $ruta;
    }
    
public function Registrar($nom,$nom1,$ape,$ape1,$ced,$tel,$correo,$user,$pass,$fecha,$rol){
    $gestionlogin=new GestionLogin();
    $tabla=$gestionlogin->persona();
    $res=0;
    $con=0;
    foreach ($tabla as $valor) {
        if($valor['cedula']==$ced){

            $con=1;
        }

        
    }

    if ($con==0) {

        $pass=password_hash($pass, PASSWORD_DEFAULT);
        $persona=new Persona($nom,$nom1,$ape,$ape1,$ced,$tel,$correo,$user,$pass,$fecha,$rol,1);
        $gestionlogin=new GestionLogin();
        $res=$gestionlogin->RegistroUsuario($persona);
        if($res==1){
    
            $res=1;
        }
    
        return $res;
    } else {
        

return -1;
    }
    

   
    
    }

    public function InicioSecion($usu,$pass){
      
        $gestionlogin=new GestionLogin();
        
        $resultado=$gestionlogin->InicioSecion($usu);

      //  $fila=$resultado->fetchObject();
$contador=0;

foreach ($resultado as $tabla) {
    $contador++;
if(password_verify($pass, $tabla['password'])){
$contador++;

if($tabla['Id_usu']==1){


    return "cliente";
     

   }

   elseif($tabla['Id_usu']==2){
   
return "fruticultor";
   }
   elseif(($tabla['Id_usu']==3) or ($tabla['Id_usu']==4)){

    return "administrador";
   }
   
    
}


   
}

if($contador==0){

    return "nada";
    
}



    }

   

    public function usuarios(){
        $gestionlogin=new GestionLogin();
        $res=$gestionlogin->usuarios();   
      return $res;
        }
        public function productos(){
            $gestionlogin=new Admimodelo();
            $res=$gestionlogin->tablapro();   
          return $res;
            }
        public function actualizarusu($ced){
            $gestionlogin=new GestionLogin();
            $res=$gestionlogin->actualizarusu($ced);   
          return $res;
            }
            
            
            public function reactualizacion($ced,$nom,$nom1,$ape,$ape1,$tel,$correo,$user,$pass){
                $gestionlogin=new GestionLogin();
                $res=$gestionlogin->reactualizacion($ced,$nom,$nom1,$ape,$ape1,$tel,$correo,$user,$pass);   
              return $res;
                }

    
            
    
    }

?>