<?php

class Sesion1{
private $nombre;
private $rol;
private $ced;
public function __construct(){
}

public function setCurrent($usu){

    $_SESSION['usu']=$usu;
}
    
public function getCurrent(){
    return $_SESSION['usu'];
}

public function closeSesion(){
    
session_unset();
session_destroy();

}

public function setUsuario($ced){
    $gestionlogin=new GestionLogin();
    $res=$gestionlogin->setUsuario($ced);
 
    foreach ($res as $tabla) {
     $this->nombre=$tabla['nombre1'];
     $this->rol=$tabla['Id_usu'];
     $this->ced=$tabla['cedula'];
  
    }
}

public function getNombre(){

    return $this->nombre;
    
    }


    public function getRol(){

        return $this->rol;
    }

   public function setRol($rol){

      $this->rol=$rol;
       }

       public function getCedula(){

        return $this->ced;
        
        }
    


}




?>