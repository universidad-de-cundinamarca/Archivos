<?php

class Usuario{
private $nombre;


public function setUsuario($ced){
    $gestionlogin=new GestionLogin();
    $res=$gestionlogin->setUsuario($ced);
 
    foreach ($res as $tabla) {
     $this->nombre=$tabla['nombre1'];
  
    }
}

public function getNombre(){

    return $this->nombre;
    
    }
 
}




?>