var $enlace = $('.actualizar').find('a').on('click', function(evento){
    evento.preventDefault();
    var $valor= this.dataset.id;
    $.ajax({
      url: 'modelo/verproducto.php' ,
      type: 'POST' ,
      dataType: 'html',
      data: {consulta: $valor},
   })
   .done(function(respuesta){
      $(".cambiar").html(respuesta);
   })
   .fail(function(){
      console.log("error");
   });
 
});






