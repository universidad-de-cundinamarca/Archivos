var $enlace = $('.cambiar').find('a').on('click', function(evento){
    
    evento.preventDefault();
var $valor= this.dataset.id;

$(".cambio").html($valor);

});