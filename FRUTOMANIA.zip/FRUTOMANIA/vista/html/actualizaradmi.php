<!-- 
* Copyright 2018 Carlos Eduardo Alfaro Orellana
  https://www.youtube.com/c/CarlosAlfaro007
-->
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Clients</title>
	<link rel="stylesheet" href="vista/css/normalize.css">
	<link rel="stylesheet" href="vista/css/sweetalert2.css">
	<link rel="stylesheet" href="vista/css/material.min.css">
	<link rel="stylesheet" href="vista/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" href="vista/css/jquery.mCustomScrollbar.css">
	<link rel="stylesheet" href="vista/css/main.css">
	<link rel="stylesheet" href="vista/css/bootstrap.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="vista/js/jquery-1.11.2.min.js"><\/script>')</script>
	<script src="vista/js/material.min.js" ></script>
	<script src="vista/js/sweetalert2.min.js" ></script>
	<script src="vista/js/jquery.mCustomScrollbar.concat.min.js" ></script>
	<script src="vista/js/main.js" ></script>
	<script src="vista/js/bootstrap.js" ></script>
</head>
<body>

	<!-- pageContent -->
	<section class="full-width">
		<!-- navBar -->
		<div class="text-left" style="padding:10px;float:left;">
				<a href="index.php?accion=inicio">				<i class="zmdi zmdi-long-arrow-left"></i>
                         Volver</a>
				</div>

                <?php


foreach ($tablaactu as $tabla) {
   $ced=$tabla['cedula'];
   $nom=$tabla['nombre1'];
   $nom1=$tabla['nombre2'];
   $ape=$tabla['apellido1'];
   $ape1=$tabla['apellido2'];
   $correo=$tabla['correo'];
   $tel=$tabla['telefono'];
   $usu=$tabla['user'];
   $pas=$tabla['password'];

}
                ?>
		<div class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect letra">
			
			<div class="mdl-tabs__panel is-active" id="tabNewClient">
				<div class="mdl-grid">
					<div class="mdl-cell mdl-cell--12-col">
						<div class="full-width panel mdl-shadow--2dp">
							<div class="full-width panel-tittle bg-primary text-center tittles">
								Actualizar Datos
							</div>
							<div class="full-width panel-content">
								<form action="index.php?accion=realiazaractualizacion"  method="post">
									<div class="mdl-grid">
										<div class="mdl-cell mdl-cell--12-col">
									        <legend class="text-condensedLight"><i class="zmdi zmdi-border-color"></i> &nbsp;Datos</legend><br>
									    </div>
									    <div class="mdl-cell mdl-cell--12-col">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input class="mdl-textfield__input" type="number" pattern="-?[0-9]*(\.[0-9]+)?" id="DNIClient" name="cedula" readonly="readonly" value="<?php echo $ced;?>">
												<label class="mdl-textfield__label" for="DNIClient">Cedula</label>
												<span class="mdl-textfield__error">Cedula Invalido</span>
											</div>
									    </div>
									    <div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input class="mdl-textfield__input" type="text" pattern="-?[A-Za-záéíóúÁÉÍÓÚñÑ ]*(\.[0-9]+)?" id="NameClient"name="nombre"required  value="<?php echo $nom;?>">
												<label class="mdl-textfield__label" for="NameClient">Primer Nombre</label>
												<span class="mdl-textfield__error">Nombre Invalido</span>
											</div>
										</div>
										<div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input class="mdl-textfield__input" type="text" pattern="-?[A-Za-záéíóúÁÉÍÓÚñÑ]*(\.[0-9]+)?" id="NameClient"name="nombre1"  value="<?php echo $nom1;?>">
												<label class="mdl-textfield__label" for="NameClient">Segundo Nombre</label>
												<span class="mdl-textfield__error">Nombre Invalido</span>
											</div>

									    </div>
									    <div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input class="mdl-textfield__input" type="text" pattern="-?[A-Za-záéíóúÁÉÍÓÚñÑ ]*(\.[0-9]+)?" id="LastNameClient"name="apellido"required  value="<?php echo $ape;?>">
												<label class="mdl-textfield__label" for="LastNameClient">Primer Apellido</label>
												<span class="mdl-textfield__error">Apellido Invalido</span>
											</div>
										</div>
										<div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input class="mdl-textfield__input" type="text" pattern="-?[A-Za-záéíóúÁÉÍÓÚñÑ ]*(\.[0-9]+)?" id="LastNameClient"name="apellido1"required  value="<?php echo $ape1;?>">
												<label class="mdl-textfield__label" for="LastNameClient">Segundo Apellido</label>
												<span class="mdl-textfield__error">Apellido Invalido</span>
											</div>
									    </div>
										<div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input class="mdl-textfield__input" type="email" id="emailClient"name="correo"required  value="<?php echo $correo;?>">
												<label class="mdl-textfield__label" for="emailClient">E-mail</label>
												<span class="mdl-textfield__error">E-mail</span>
											</div>
									    </div>
									    <div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input class="mdl-textfield__input" type="number" pattern="[0-9]+" id="phoneClient"name="telefono"required value="<?php echo $tel;?>">
												<label class="mdl-textfield__label" for="phoneClient">Telefono</label>
												<span class="mdl-textfield__error">TelefonoError</span>
											</div>
										</div>
										<div class="mdl-cell mdl-cell--12-col">
									        <legend class="text-condensedLight"><i class="zmdi zmdi-border-color"></i> &nbsp;Datos de Usuario</legend><br>
											<div class="mdl-cell mdl-cell--12-col">
										<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
										<input class="mdl-textfield__input" type="text" pattern="-?[A-Za-záéíóúÁÉÍÓÚ-(0-9)]" id="NameClient"name="user"required  value="<?php echo $usu;?>">
												<label class="mdl-textfield__label" for="NameClient">Usuario</label>
										</div>
										</div>	

										<div class="mdl-cell mdl-cell--12-col">
										<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				   						 <input class="mdl-textfield__input" type="password" name="password" id="pass"required value="<?php echo $pas;?>">
				   						 <label class="mdl-textfield__label" for="pass">Contraseña</label>
										</div>
										</div>		
										<p class="text-center">
										<button class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored bg-primary" id="btn-addAdmin">
											<i class="zmdi zmdi-plus"></i>
										</button>
										<div class="mdl-tooltip" for="btn-addAdmin">Actualizar datos</div>
									</p>
									  
									</div>
								
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		
	</section>
	<footer class="footer">
      <div class="contenedor">
        <div class="social" style="font-size: 40px;">
          <a href="#" ><i class="zmdi zmdi-whatsapp"></i>
</a>
          <a href="#"><i class="zmdi zmdi-facebook-box"></i>
</a>
          <a href="#" ><i class="zmdi zmdi-youtube"></i>
</a>
          <a href="#"></a>
        </div>
      
      </div>
    </footer>
</body>
</html>