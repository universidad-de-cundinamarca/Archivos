<!-- 
* Copyright 2018 Carlos Eduardo Alfaro Orellana
  https://www.youtube.com/c/CarlosAlfaro007
-->
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Inventario</title>
	<link rel="stylesheet" href="vista/css/normalize.css">
	<link rel="stylesheet" href="vista/css/sweetalert2.css">
	<link rel="stylesheet" href="vista/css/material.min.css">
	<link rel="stylesheet" href="vista/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" href="vista/css/jquery.mCustomScrollbar.css">
	<link rel="stylesheet" href="vista/css/main.css">
	<link rel="stylesheet" href="vista/css/bootstrap.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="vista/js/jquery-1.11.2.min.js"><\/script>')</script>
	<script src="vista/js/material.min.js" ></script>
	<script src="vista/js/sweetalert2.min.js" ></script>
	<script src="vista/js/jquery.mCustomScrollbar.concat.min.js" ></script>
	<script src="vista/js/main.js" ></script>
	<script src="vista/js/bootstrap.js" ></script>
</head>
<body>
		<!-- Notifications area -->
<section class="full-width container-notifications">
		<div class="full-width container-notifications-bg btn-Notification"></div>
	    <section class="NotificationArea">
	        <div class="full-width text-center NotificationArea-title tittles">Frutomania <i class="zmdi zmdi-close btn-Notification"></i></div>
	        <a href="index.php?accion=actualizardatos" class="Notification" id="notifation-unread-1">
	            <div class="Notification-icon"><i class="zmdi zmdi-accounts-alt bg-info"></i></div>
	            <div class="Notification-text">
	                <p>
	                    <i class="zmdi zmdi-circle"></i>
	                    <strong>Actualizar Datos</strong> 
	                   
	                  
	                </p>
	            </div>
	        	<div class="mdl-tooltip mdl-tooltip--left" for="notifation-unread-1">Actualizar Datos</div> 
	        </a>
	        <a href="index.php?accion=salir" class="Notification" id="notifation-read-1">
	            <div class="Notification-icon"><i class="zmdi zmdi-power bg-primary"></i></div>
	            <div class="Notification-text">
	                <p>
	                    <i class="zmdi zmdi-circle-o"></i>
	                    <strong>Cerrar Sesion</strong> 
	                    
	                </p>
	            </div>
	            <div class="mdl-tooltip mdl-tooltip--left" for="notifation-read-1">Cerrar Sesion</div>
	        </a>
	        
	    </section>
	</section>

	

	<!-- navLateral -->
	<section class="full-width navLateral">
		<div class="full-width navLateral-bg btn-menu"></div>
		<div class="full-width navLateral-body">
			<a href="index.php?accion=refresco" style="text-decoration: none;"  >
				<div class="full-width navLateral-body-logo text-center tittles">
				<i class="zmdi zmdi-close btn-menu"></i> Frutomania
				</div>
			</a>
			

			<?php
			
			if(isset($_SESSION['usu'])){
				$nombre=$sesion->getNombre();
				if($sesion->getRol()==1){
					echo "<figure class='full-width navLateral-body-tittle-menu'>
					<div>
						<img src='vista/assets/img/cliente.png' alt='Avatar' class='img-responsive'>
					</div>
					<figcaption>
						<span>
					   
					   Bienvenido $nombre
	   
						<br>
							<small>Cliente</small>
						</span>
					</figcaption>
				</figure>";
				}
				elseif($sesion->getRol()==2){
					echo "<figure class='full-width navLateral-body-tittle-menu'>
			 <div>
				 <img src='vista/assets/img/avatar-male.png' alt='Avatar' class='img-responsive'>
			 </div>
			 <figcaption>
				 <span>
				
				Bienvenido $nombre

				 <br>
					 <small>Fruticultor</small>
				 </span>
			 </figcaption>
		 </figure>";
			   }
			   elseif($sesion->getRol()==3){
				echo "<figure class='full-width navLateral-body-tittle-menu'>
				<div>
					<img src='vista/assets/img/jhon1.png' alt='Avatar' class='img-responsive'>
				</div>
				<figcaption>
					<span>
				   
				   Bienvenido $nombre
   
					<br>
						<small> Administrador </small>
					</span>
				</figcaption>
			</figure>";
		   }   elseif($sesion->getRol()==4){
				echo "<figure class='full-width navLateral-body-tittle-menu'>
				<div>
					<img src='vista/assets/img/avatar-male.png' alt='Avatar' class='img-responsive'>
				</div>
				<figcaption>
					<span>
				   
				   Bienvenido $nombre
   
					<br>
						<small> Administrador </small>
					</span>
				</figcaption>
			</figure>";
		   }
			
             
			}
			else{
				echo "<figure class='full-width navLateral-body-tittle-menu'>
				<div>
					<img src='vista/assets/img/fuera.png' alt='Avatar' class='img-responsive'>
				</div>
				<figcaption>
					<span>
					 
					 Bienvenido 
	 
					<br>
				 
					</span>
				</figcaption>
			</figure>";}
			?>
			
			<nav class="full-width">
				<ul class="full-width list-unstyle menu-principal">
					<li class="full-width">
						<a href="index.php?accion=inicio" class="full-width">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-view-dashboard"></i>
							</div>
							<div class="navLateral-body-cr">
								INICIO
							</div>
						</a>
					</li>
					<li class="full-width divider-menu-h"></li>
					<li class="full-width">
						<a class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-case"></i>
							</div>
							<div class="navLateral-body-cr">
								PRODUCTOS
							</div>
							<span class="zmdi zmdi-chevron-left"></span>
						</a>
						<ul class="full-width menu-principal sub-menu-options">
							<li class="full-width">
								<a href="index.php?accion=frutas" class="full-width">
									<div class="navLateral-body-cl">
										<i class="zmdi zmdi-balance"></i>
									</div>
									<div class="navLateral-body-cr">
										FRUTAS
									</div>
								</a>
							</li>
						
							<li class="full-width">
						
								<a href="https://www.corabastos.com.co/sitio/historicoApp2/reportes/BoletinDescarga.php" 
								class="full-width"  target="_blank">
									
								  	<div class="navLateral-body-cl">
										<i class="zmdi zmdi-card"></i>
									</div>
									<div class="navLateral-body-cr">
										PRECIOS
									</div>
								</a>
							</li>
							
						</ul>
					</li>
					<li class="full-width divider-menu-h"></li>
					<?php
					 if( (!isset($_SESSION['usu'])) or ($sesion->getRol()==3) or ($sesion->getRol()==4)){

						echo '<li class="full-width">
						<a  class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-face"></i>
							</div>
							<div class="navLateral-body-cr">
								USUARIO
							</div>
							<span class="zmdi zmdi-chevron-left"></span>
						</a>
						<ul class="full-width menu-principal sub-menu-options">
							<li class="full-width">
								<a href="index.php?accion=cliente" class="full-width">
									<div class="navLateral-body-cl">
										<i class="zmdi zmdi-account"></i>
									</div>
									<div class="navLateral-body-cr">
										CLIENTE
									</div>
								</a>
							</li>
							<li class="full-width">
								<a href="index.php?accion=fruticultor" class="full-width">
									<div class="navLateral-body-cl">
										<i class="zmdi zmdi-accounts"></i>
									</div>
									<div class="navLateral-body-cr">
										FRUTICULTOR
									</div>
								</a>
							</li>';
if($sesion->getRol()==3){

	echo '<li class="full-width">
	<a href="index.php?accion=administrador" class="full-width">
		<div class="navLateral-body-cl">
			<i class="zmdi zmdi-accounts"></i>
		</div>
		<div class="navLateral-body-cr">
			ADMINISTRADOR
		</div>
	</a>
</li>';}
echo '

						</ul>
					</li>';
					 }
					 ?>
					
					<li class="full-width divider-menu-h"></li>
					<?php
					 if(isset($_SESSION['usu'])){
						 if($sesion->getRol()==1){
					 }
					 
					 elseif($sesion->getRol()==2){
						 echo '<li class="full-width divider-menu-h"></li>
						 <li class="full-width">
							<a  class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
									<i class="zmdi zmdi-store"></i>
								</div>

								<div class="navLateral-body-cr">
								INVENTARIO
								</div>

								<span class="zmdi zmdi-chevron-left"></span>
							</a>

							 <ul class="full-width menu-principal sub-menu-options">
								<li class="full-width">
									<a  href="index.php?accion=inventario" class="full-width" >
										<div class="navLateral-body-cl">
											<i class="zmdi zmdi-widgets"></i>
										</div>
										<div class="navLateral-body-cr">
											PRODUCTOS AGREGADOS
										</div>
									</a>
								</li>
								<li class="full-width">
									<a href="index.php?accion=agregarproductoinventario" class="full-width">
										<div class="navLateral-body-cl">
											<i class="zmdi zmdi-widgets"></i>
										</div>
										<div class="navLateral-body-cr">
											AGREGAR PRODUCTOS
										</div>
							 		</a>
								 </li>
					 		</ul>
				 		</li>';
					}
					elseif($sesion->getRol()==3 or $sesion->getRol()==4){
						echo '<li class="full-width divider-menu-h"></li>
						<li class="full-width">
						<a href="index.php?accion=frutiadmi" class="full-width">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-widgets"></i>
							</div>
							<div class="navLateral-body-cr">
								ADMINISTRADOR
							</div>
						</a>
					</li>
						</li>';
				}
					 else{


					 }
					}
					
					 ?>
					
					<li class="full-width">
						<a href="index.php?accion=quienes" class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-wrench"></i>
							</div>
							<div class="navLateral-body-cr">
								QUIENES SOMOS?
							</div>
						</a>
					</li>
				</ul>
			</nav>
		</div>
	</section>

	<!-- pageContent -->
	<section class="full-width pageContent">
		<!-- navBar -->
		<div class="full-width navBar">
			<div class="full-width navBar-options">
				<i class="zmdi zmdi-swap btn-menu" id="btn-menu"></i>	
				<div class="mdl-tooltip" for="btn-menu">Hide / Show MENU</div>


				<nav class="navBar-options-list">
					
					<ul class="list-unstyle">

					<?php
					if (isset($_SESSION['usu'])) {


						echo "	<li >
						<a href='index.php?accion=salir' class='full-width' title='Salir '>
							<i class='zmdi zmdi-power'></i>
							</a>
							
						</li>
						<li class='text-condensedLight noLink' ><small>$nombre</small></li>
						
						<li class='btn-Notification' id='notifications'>
						<i class='zmdi zmdi-chevron-down'></i>
						</li>";
					}
					else{
						echo "
						<a href='index.php?accion=iniciosesion' class='full-width'>
						<li>
						<i class='zmdi zmdi-power'>  Iniciar Sesion</i>
						<div class='mdl-tooltip' for='btn-exit'>Salir</div>
					</li>
					</a>
						";


					}
					
					?>
						
					</ul>
				</nav>
			</div>
		</div>
		
		

		
		<h3 class="text-center tittles">Agregar Productos</h3>

		
				<div class="mdl-grid">
					<div class="mdl-cell mdl-cell--12-col">
						<div class="full-width panel mdl-shadow--2dp">
							<div class="full-width panel-tittle bg-primary text-center tittles">
								Nuevo Producto
							</div>
							<div class="full-width panel-content">
								<form  method="post" action="index.php?accion=agregarproducto"    >
									<div class="mdl-grid">
										<div class="mdl-cell mdl-cell--12-col">
									        <legend class="text-condensedLight"><i class="zmdi zmdi-border-color"></i> &nbsp; Informacion Basica</legend><br>
										</div>

										<div class="mdl-cell mdl-cell--12-col">
											<div class="mdl-textfield mdl-js-textfield">
												<select name="producto" class="mdl-textfield__input"  >
													<option value="nada"  selected="">Seleccione Producto</option>
												

													<?php

											
													  foreach ($tablapro as $tabla) {
														$valor=$tabla['Id'];
														$valor1=$tabla['nombre'];
														
														echo "<option value='$valor'>$valor $valor1</option>";

													   }
													?>
													

												</select>
											</div>
										</div>

						
										<div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input name="descripcion" class="mdl-textfield__input" type="text" id="NameProduct">
												<label class="mdl-textfield__label" for="NameProduct">Descripcion</label>
												<span class="mdl-textfield__error">Descripcion</span>
											</div>
										</div>
										<div class="mdl-cell mdl-cell--4-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input name="cantidad"class="mdl-textfield__input" type="number" pattern="-?[0-9]*(\.[0-9]+)?" id="StrockProduct" required >
												<label class="mdl-textfield__label" for="StrockProduct">Catidad por Kilos</label>
												<span class="mdl-textfield__error">Numero Invalido</span>
											</div>
										</div>
										<div class="mdl-cell mdl-cell--4-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
												<input name="precio"class="mdl-textfield__input" type="number" pattern="-?[0-9]*(\.[0-9]+)?" id="PriceProduct" required>
												<label class="mdl-textfield__label" for="PriceProduct">Precio por Kilo </label>
												<span class="mdl-textfield__error">Precio Invalido</span>
											</div>
										</div>
										<div class="mdl-cell mdl-cell--4-col mdl-cell--8-col-tablet">
											<div class="mdl-textfield mdl-js-textfield">
												<select name="estado" class="mdl-textfield__input">
												
													<option value="1"selected="" >Activo</option>
													<option value="2">En Cotizacion</option>
													<option value="3">Vendido</option>

												</select>
											</div>
										</div>
									
										
										<div class="mdl-cell mdl-cell--12-col">
									        <legend class="text-condensedLight"><i class="zmdi zmdi-border-color"></i> &nbsp; Datos Complementarios</legend><br>
									    </div>
										<div class="mdl-cell mdl-cell--4-col mdl-cell--8-col-tablet">
										<label >Fecha de Duracion de producto</label>
											<div class="mdl-textfield mdl-js-textfield">

												<input type="date" class="mdl-textfield__input" name="fechafin">
												
											</div>
										</div>
										
									
									</div>
									<p class="text-center">
										<button class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored bg-primary" id="btn-addProduct">
											<i class="zmdi zmdi-plus"></i>
											
										</button>
										<div class="mdl-tooltip" for="btn-addProduct">Agregar Producto</div>
									</p>
								</form>
							</div>
						</div>
					</div>
				</div>
			
	</section>
	<footer class="footer">
      <div class="contenedor">
        <div class="social" style="font-size: 40px;">
          <a href="#" ><i class="zmdi zmdi-whatsapp"></i>
</a>
          <a href="#"><i class="zmdi zmdi-facebook-box"></i>
</a>
          <a href="#" ><i class="zmdi zmdi-youtube"></i>
</a>
          <a href="#"></a>
        </div>
      
      </div>
    </footer>
</body>
</html>