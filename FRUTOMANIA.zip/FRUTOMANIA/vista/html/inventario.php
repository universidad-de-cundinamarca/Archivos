<!-- 
* Copyright 2018 Carlos Eduardo Alfaro Orellana
  https://www.youtube.com/c/CarlosAlfaro007
-->
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Inventario</title>
	<link rel="stylesheet" href="vista/css/normalize.css">
	<link rel="stylesheet" href="vista/css/sweetalert2.css">
	<link rel="stylesheet" href="vista/css/material.min.css">
	<link rel="stylesheet" href="vista/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" href="vista/css/jquery.mCustomScrollbar.css">
	<link rel="stylesheet" href="vista/css/main.css">
	<link rel="stylesheet" href="vista/css/bootstrap.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="vista/js/jquery-1.11.2.min.js"><\/script>')</script>
	<script src="vista/js/material.min.js" ></script>
	<script src="vista/js/sweetalert2.min.js" ></script>
	<script src="vista/js/jquery.mCustomScrollbar.concat.min.js" ></script>
	<script src="vista/js/main.js" ></script>
	<script src="vista/js/bootstrap.js" ></script>
</head>
<body>
<section class="full-width container-notifications">
		<div class="full-width container-notifications-bg btn-Notification"></div>
	    <section class="NotificationArea">
	        <div class="full-width text-center NotificationArea-title tittles">Frutomania <i class="zmdi zmdi-close btn-Notification"></i></div>
	        <a href="index.php?accion=actualizardatos" class="Notification" id="notifation-unread-1">
	            <div class="Notification-icon"><i class="zmdi zmdi-accounts-alt bg-info"></i></div>
	            <div class="Notification-text">
	                <p>
	                    <i class="zmdi zmdi-circle"></i>
	                    <strong>Actualizar Datos</strong> 
	                   
	                  
	                </p>
	            </div>
	        	<div class="mdl-tooltip mdl-tooltip--left" for="notifation-unread-1">Actualizar Datos</div> 
	        </a>
	        <a href="index.php?accion=salir" class="Notification" id="notifation-read-1">
	            <div class="Notification-icon"><i class="zmdi zmdi-power bg-primary"></i></div>
	            <div class="Notification-text">
	                <p>
	                    <i class="zmdi zmdi-circle-o"></i>
	                    <strong>Cerrar Sesion</strong> 
	                    
	                </p>
	            </div>
	            <div class="mdl-tooltip mdl-tooltip--left" for="notifation-read-1">Cerrar Sesion</div>
	        </a>
	        
	    </section>
	</section>
	<!-- Notifications area -->
	
	<!-- navLateral -->
	<section class="full-width navLateral">
		<div class="full-width navLateral-bg btn-menu"></div>
		<div class="full-width navLateral-body">
			<a href="index.php?accion=refresco" style="text-decoration: none;"  >
				<div class="full-width navLateral-body-logo text-center tittles">
				<i class="zmdi zmdi-close btn-menu"></i> Frutomania
				</div>
			</a>
			

			<?php
			
			if(isset($_SESSION['usu'])){
				$nombre=$sesion->getNombre();
				if($sesion->getRol()==1){
					echo "<figure class='full-width navLateral-body-tittle-menu'>
					<div>
						<img src='vista/assets/img/cliente.png' alt='Avatar' class='img-responsive'>
					</div>
					<figcaption>
						<span>
					   
					   Bienvenido $nombre
	   
						<br>
							<small>Cliente</small>
						</span>
					</figcaption>
				</figure>";
				}
				elseif($sesion->getRol()==2){
					echo "<figure class='full-width navLateral-body-tittle-menu'>
			 <div>
				 <img src='vista/assets/img/avatar-male.png' alt='Avatar' class='img-responsive'>
			 </div>
			 <figcaption>
				 <span>
				
				Bienvenido $nombre

				 <br>
					 <small>Fruticultor</small>
				 </span>
			 </figcaption>
		 </figure>";
			   }
			   elseif($sesion->getRol()==3){
				echo "<figure class='full-width navLateral-body-tittle-menu'>
				<div>
					<img src='vista/assets/img/jhon1.png' alt='Avatar' class='img-responsive'>
				</div>
				<figcaption>
					<span>
				   
				   Bienvenido $nombre
   
					<br>
						<small> Administrador </small>
					</span>
				</figcaption>
			</figure>";
		   }   elseif($sesion->getRol()==4){
				echo "<figure class='full-width navLateral-body-tittle-menu'>
				<div>
					<img src='vista/assets/img/avatar-male.png' alt='Avatar' class='img-responsive'>
				</div>
				<figcaption>
					<span>
				   
				   Bienvenido $nombre
   
					<br>
						<small> Administrador </small>
					</span>
				</figcaption>
			</figure>";
		   }
			
             
			}
			else{
				echo "<figure class='full-width navLateral-body-tittle-menu'>
				<div>
					<img src='vista/assets/img/fuera.png' alt='Avatar' class='img-responsive'>
				</div>
				<figcaption>
					<span>
					 
					 Bienvenido 
	 
					<br>
				 
					</span>
				</figcaption>
			</figure>";}
			?>
			
			<nav class="full-width">
				<ul class="full-width list-unstyle menu-principal">
					<li class="full-width">
						<a href="index.php?accion=inicio" class="full-width">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-view-dashboard"></i>
							</div>
							<div class="navLateral-body-cr">
								INICIO
							</div>
						</a>
					</li>
					<li class="full-width divider-menu-h"></li>
					<li class="full-width">
						<a class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-case"></i>
							</div>
							<div class="navLateral-body-cr">
								PRODUCTOS
							</div>
							<span class="zmdi zmdi-chevron-left"></span>
						</a>
						<ul class="full-width menu-principal sub-menu-options">
							<li class="full-width">
								<a href="index.php?accion=frutas" class="full-width">
									<div class="navLateral-body-cl">
										<i class="zmdi zmdi-balance"></i>
									</div>
									<div class="navLateral-body-cr">
										FRUTAS
									</div>
								</a>
							</li>
						
							<li class="full-width">
						
								<a href="https://www.corabastos.com.co/sitio/historicoApp2/reportes/BoletinDescarga.php" 
								class="full-width"  target="_blank">
									
								  	<div class="navLateral-body-cl">
										<i class="zmdi zmdi-card"></i>
									</div>
									<div class="navLateral-body-cr">
										PRECIOS
									</div>
								</a>
							</li>
							
						</ul>
					</li>
					<li class="full-width divider-menu-h"></li>
					<?php
					 if( (!isset($_SESSION['usu'])) or ($sesion->getRol()==3) or ($sesion->getRol()==4)){

						echo '<li class="full-width">
						<a  class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-face"></i>
							</div>
							<div class="navLateral-body-cr">
								USUARIO
							</div>
							<span class="zmdi zmdi-chevron-left"></span>
						</a>
						<ul class="full-width menu-principal sub-menu-options">
							<li class="full-width">
								<a href="index.php?accion=cliente" class="full-width">
									<div class="navLateral-body-cl">
										<i class="zmdi zmdi-account"></i>
									</div>
									<div class="navLateral-body-cr">
										CLIENTE
									</div>
								</a>
							</li>
							<li class="full-width">
								<a href="index.php?accion=fruticultor" class="full-width">
									<div class="navLateral-body-cl">
										<i class="zmdi zmdi-accounts"></i>
									</div>
									<div class="navLateral-body-cr">
										FRUTICULTOR
									</div>
								</a>
							</li>';
if($sesion->getRol()==3){

	echo '<li class="full-width">
	<a href="index.php?accion=administrador" class="full-width">
		<div class="navLateral-body-cl">
			<i class="zmdi zmdi-accounts"></i>
		</div>
		<div class="navLateral-body-cr">
			ADMINISTRADOR
		</div>
	</a>
</li>';}
echo '

						</ul>
					</li>';
					 }
					 ?>
					
					<li class="full-width divider-menu-h"></li>
					<?php
					 if(isset($_SESSION['usu'])){
						 if($sesion->getRol()==1){
					 }
					 
					 elseif($sesion->getRol()==2){
						 echo '<li class="full-width divider-menu-h"></li>
						 <li class="full-width">
							<a  class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
									<i class="zmdi zmdi-store"></i>
								</div>

								<div class="navLateral-body-cr">
								INVENTARIO
								</div>

								<span class="zmdi zmdi-chevron-left"></span>
							</a>

							 <ul class="full-width menu-principal sub-menu-options">
								<li class="full-width">
									<a  href="index.php?accion=inventario" class="full-width" >
										<div class="navLateral-body-cl">
											<i class="zmdi zmdi-widgets"></i>
										</div>
										<div class="navLateral-body-cr">
											PRODUCTOS AGREGADOS
										</div>
									</a>
								</li>
								<li class="full-width">
									<a href="index.php?accion=agregarproductoinventario" class="full-width">
										<div class="navLateral-body-cl">
											<i class="zmdi zmdi-widgets"></i>
										</div>
										<div class="navLateral-body-cr">
											AGREGAR PRODUCTOS
										</div>
							 		</a>
								 </li>
					 		</ul>
				 		</li>';
					}
					elseif($sesion->getRol()==3 or $sesion->getRol()==4){
						echo '<li class="full-width divider-menu-h"></li>
						<li class="full-width">
						<a href="index.php?accion=frutiadmi" class="full-width">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-widgets"></i>
							</div>
							<div class="navLateral-body-cr">
								ADMINISTRADOR
							</div>
						</a>
					</li>
						</li>';
				}
					 else{


					 }
					}
					
					 ?>
					
					<li class="full-width">
						<a href="index.php?accion=quienes" class="full-width btn-subMenu">
							<div class="navLateral-body-cl">
								<i class="zmdi zmdi-wrench"></i>
							</div>
							<div class="navLateral-body-cr">
								QUIENES SOMOS?
							</div>
						</a>
					</li>
				</ul>
			</nav>
		</div>
	</section>

	<!-- pageContent -->
	<section class="full-width pageContent">
		<!-- navBar -->
		<div class="full-width navBar">
			<div class="full-width navBar-options">
				<i class="zmdi zmdi-swap btn-menu" id="btn-menu"></i>	
				<div class="mdl-tooltip" for="btn-menu">Hide / Show MENU</div>


				<nav class="navBar-options-list">
					
					<ul class="list-unstyle">

					<?php
					if (isset($_SESSION['usu'])) {


						echo "	<li >
						<a href='index.php?accion=salir' class='full-width' title='Salir '>
							<i class='zmdi zmdi-power'></i>
							</a>
							
						</li>
						<li class='text-condensedLight noLink' ><small>$nombre</small></li>
						
						<li class='btn-Notification' id='notifications'>
						<i class='zmdi zmdi-chevron-down'></i>
						</li>";
					}
					else{
						echo "
						<a href='index.php?accion=iniciosesion' class='full-width'>
						<li>
						<i class='zmdi zmdi-power'>  Iniciar Sesion</i>
						<div class='mdl-tooltip' for='btn-exit'>Salir</div>
					</li>
					</a>
						";


					}
					
					?>
						
					</ul>
				</nav>
			</div>
		</div>

		
		<div class="cambiar">
		<div class="text-left" style="padding:10px;float:left;">
				<a href="index.php?accion=frutas">				<i class="zmdi zmdi-long-arrow-left"></i>
                         Catalogo</a>
				</div>
		<div class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect">
							<div class="mdl-tabs__tab-bar">
								<a href="#tabNewProduct" class="mdl-tabs__tab is-active">Todos</a>
								<a href="#tabListProducts" class="mdl-tabs__tab">En Cotizacion</a>
								<a href="#tabvenProducts" class="mdl-tabs__tab">Pre-Vendidos</a>
							</div>
							<br><br>
							<div class="mdl-tabs__panel is-active" id="tabNewProduct">
								<h3 class="text-center tittles">Productos Agregados</h3>
								<div class="full-width divider-menu-h"></div>
								<div class=" mdl-grid">
									
									<div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--12-col-desktop">
										<div class=" table-responsive principal">
											<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp full-width table-responsive">
												<thead>
													<tr>
														<th class="mdl-data-table__cell--non-numeric">Nombre</th>
														<th>Id</th>
														<th>Fecha Finalizacion</th>
														<th>Cantidad</th>
														<th>Precio</th>
														<th>Options</th>
														<th></th>
														<th>Estado</th>
													</tr>
												</thead>
												<tbody>	<?php
												$cont="";

																	
														foreach ($tablaproarriba as $tabla) {
														$valor=$tabla['nombre'];
														$valor1=$tabla['precio'];
														$valor2=$tabla['fecha_fin'];
														$valor3=$tabla['cantidad'];
														$valor4=$tabla['id_arriba'];
														if ($tabla['estado']==1) {
														$estado="Activo";
														}
														if ($tabla['estado']==2) {
															$estado="En Cotizacion";
															}
															if ($tabla['estado']==3) {
																$estado="Vendido";
																}
																if ($tabla['estado']==4) {
																	$estado="InCotizacion";
																	}
														
														echo "<tr>
														<td class='mdl-data-table__cell--non-numeric'>$valor</td>
														<td> $valor4</td>
														<td> $valor2</td>
														<td>$valor3 (Kilos)</td>
														<td>$ $valor1</td>
														<td class='actualizar'> 
														<a type='button' class='btn btn-primary' data-id='$valor4' >
														Actualizar" ;
														echo "
														</a>	
														</td>
														<td> 
														<a  type='button' class='btn btn-primary' href='javascript:eliminar($valor4)' >
														Eliminar
														</a>	
														</td>
														<td> $estado</td>
													
													</tr>";

														}

													
														?>

														

												</tbody>
											</table>
														<br><br>
														<div class="ar"><a href="index.php?accion=agregarproductoinventario" class="btn btn-secondary btn-lg btn-block">Agregar Producto</a>
													</div>
																	</div>
																</div>
															</div>
								
								</div>
									

											<div class="mdl-tabs__panel" id="tabListProducts">

											<h3 class="text-center tittles">Productos En Cotizacion</h3>
											<div class="full-width divider-menu-h"></div>
										<div class=" mdl-grid">
											
											<div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--12-col-desktop">
												<div class=" table-responsive principal">
													<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp full-width table-responsive">
														<thead>
															<tr>
																<th class="mdl-data-table__cell--non-numeric">Nombre</th>
																
																<th>Cantidad</th>
																<th>Precio Por kilo</th>
																<th>Valor Total</th>
																<th>Comprador</th>
																<th>Telefono</th>
																<th>Options</th>
																<th></th>
																
															</tr>
														</thead>
														<tbody>	<?php
														

																			
																foreach ($tablaproarribacotizado as $tabla) {
																$valor=$tabla['nombre'];
																$valor1=$tabla['precio'];
																$valor3=$tabla['ofrecer'];
																$vendedor=$tabla['fruticultor'];
																$cliente=$tabla['comerciante'];
																$producto=$tabla['Id'];
																$des=$tabla['descripcion'];
																if($valor3==$tabla['cantidad']){
																	$etd=1;



																}else{

																	$etd=4;
																}
																$valor4=$tabla['id_arriba'];
																$id=$tabla['id_productocomerciante'];
																$nombre1=$tabla['nombre1'];
																
			
																$telefono=$tabla['telefono'];
																if($tabla['cantidad']==0){

																	$cantidadcom=$valor3;
																	$tar="true";

																}else{
																	$cantidadcom=$tabla['cantidad']+$valor3;
																	$tar="false";

																}
																$valortotal=$valor1*$valor3;
																$estar=$tabla['estado'];
																if ($tabla['estado']==1) {
																$estado="Activo";
																}
																if ($tabla['estado']==2) {
																	$estado="En Cotizacion";
																	}
																	if ($tabla['estado']==3) {
																		$estado="Vendido";
																		}
																		if ($tabla['estado']==4) {
																			$estado="Incotizacion";
																			}
																
																echo "<tr>
																<td class='mdl-data-table__cell--non-numeric'>$valor</td>
															
																<td>$valor3 (Kilos)</td>
																<td>$ $valor1</td>
																<td>$ $valortotal</td>
																<td>$nombre1 </td>
																<td> $telefono</td>
																<td> 
																<a type='button' class='btn btn-primary' href='index.php?accion=cancelarcoti&id=$id&estado=6&tar=$tar&ida=$valor4&nombre=$valor&precio=$valor1&vendedor=$vendedor&cantidad=$valor3&cliente=$cliente'>
																Realizar Pre-Venta" ;
																
																echo "
																</a>	
																</td>
																<td> 
																<a  type='button' class='btn btn-primary' href='index.php?accion=cancelarcoti&id=$valor4&estado=5&cantidad=$cantidadcom&ida=$id&etd=$etd&ofrece=$valor3&precio=$valor1&vendedor=$vendedor&producto=$producto&des=$des' >
																Cancelar Venta
																</a>	
																</td>
																
															
															</tr>";

																}

															
																?>

																

														</tbody>
													</table>
													</div>
													</div>
													</div>
								
											</div>

											<div class="mdl-tabs__panel" id="tabvenProducts">

											<h3 class="text-center tittles">Productos Pre-Vendidos</h3>

											<div class="full-width divider-menu-h"></div>
										<div class=" mdl-grid">
											
											<div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--12-col-desktop">
												<div class=" table-responsive principal">
													<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp full-width table-responsive">
														<thead>
															<tr>
																<th class="mdl-data-table__cell--non-numeric">Nombre</th>
																
																<th>Cantidad</th>
																<th>Precio Por kilo</th>
																<th>Valor Total</th>
																<th>Comprador</th>
																<th>Telefono</th>
																
																<th></th>
																
															</tr>
														</thead>
														<tbody>	<?php
												

																			
																foreach ($tablavendidos as $tabla) {
																$valor=$tabla['nombre'];
																$valor1=$tabla['precio'];
																$valor3=$tabla['cantidad'];
																
																$nombre1=$tabla['nombre1'];
																$telefono=$tabla['telefono'];
																
																$valortotal=$valor1*$valor3;
																
														
																
																echo "<tr>
																<td class='mdl-data-table__cell--non-numeric'>$valor</td>
															
																<td>$valor3 (Kilos)</td>
																<td>$ $valor1</td>
																<td>$ $valortotal</td>
																<td>$nombre1 </td>
																<td> $telefono</td>" ;
																
																echo "
															</tr>";

																}

															
																?>

																

														</tbody>
													</table>
													</div>
													</div>
													</div>

										  	</div>
							</div>
	</section>
	<footer class="footer">
      <div class="contenedor">
        <div class="social" style="font-size: 40px;">
          <a href="#" ><i class="zmdi zmdi-whatsapp"></i>
</a>
          <a href="#"><i class="zmdi zmdi-facebook-box"></i>
</a>
          <a href="#" ><i class="zmdi zmdi-youtube"></i>
</a>
          <a href="#"></a>
        </div>
      
      </div>
    </footer>
	<script language="javascript1.2">
	function eliminar($numero)
{

var statusConfirm = confirm("Estas seguro que quieres eliminar el producto numero: " + $numero +"?"); 
 if (statusConfirm == true) 
 { 
	
    document.location.href="index.php?accion=eliminarproducto&id="+$numero;
 } 
 else 
 { 
   document.location.href= "index.php?accion=inventario";
 } 
 }
	</script>


	<script src="vista/js/principal.js" ></script>
</body>
</html>

