<?php
class Admimodelo{

public function tablaadmi(){

    $conexion=new Conexion();
    $conexion->abrir();

    $sql="select usuario.*,persona.* from usuario,persona where (Id_usu=3 or Id_usu=4) and usuario.cedula=persona.cedula";

    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function tablacomer(){

    $conexion=new Conexion();
    $conexion->abrir();

    $sql="select usuario.*,persona.* from usuario,persona where Id_usu=1 and usuario.cedula=persona.cedula";

    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function tablafruti(){

    $conexion=new Conexion();
    $conexion->abrir();

    $sql="select usuario.*,persona.* from usuario,persona where Id_usu=2 and usuario.cedula=persona.cedula";

    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function tablapro(){

    $conexion=new Conexion();
    $conexion->abrir();

    $sql="select * from producto ";

    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function tablacoti(){

    $conexion=new Conexion();
    $conexion->abrir();

    $sql="select producto_comerciante.*,producto_arriba.*,producto.* 
    from producto_comerciante,producto_arriba,producto
    where producto_comerciante.producto=producto_arriba.id_arriba and fruta=Id
     ";

    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function tablapre(){

    $conexion=new Conexion();
    $conexion->abrir();

    $sql="select *
    from prevendidos
   
     ";

    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
}


?>