<?php

$salida = "";
$salida1 = ""; 

require_once 'Conexion.php';
$conexion=new Conexion();
$conexion->abrir();


if (isset($_POST['consulta'])) {
    $q = $_POST['consulta'];
    $sql="select producto.*,producto_arriba.*,persona.* from producto,producto_arriba,persona 
    where  producto_arriba.fruta=producto.Id 
    and producto_arriba.fruticultor=persona.cedula 
    and producto_arriba.id_arriba=$q" ;
    $sql1="select * from producto";
    $conexion->consulta1($sql);
    $tablaproductoarriba=$conexion->obtenerResult();
    $conexion->cerrar();
    $conexion->abrir();
    $conexion->consulta1($sql1);
    $tablapro=$conexion->obtenerResult();
    
}

foreach ($tablaproductoarriba as $dato) {
       
    $id=$dato['id_arriba'];
    $des=$dato['descripcion'];
    $nombre=$dato['nombre'];
    $precio=$dato['precio'];
    $cantidad=$dato['cantidad'];
    $nombre1=$dato['nombre1'];
    $apellido1=$dato['apellido1'];
    $telefono=$dato['telefono'];
    $id2=$dato['Id'];
   $fecha=$dato['fecha_fin'];
    if($dato['estado']==1){
      $estado="Activo";
      $num=1;
    }
    if($dato['estado']==2){
      $estado="En Cotizacion";
      $num=2;
    }
    if($dato['estado']==3){
      $estado="Vendido";
      $num=3;
    }
    if($dato['estado']==4){
      $estado="Incontizacion";
      $num=4;
    }
}

    $salida.="<div class='full-width panel-tittle  tittles' style='background-color: dimgrey;'>
                   Fruta N°  $id
   </div>

 <img src='vista/imagenes/$nombre.png' alt='product' class='img-responsive1'>

<p class='full-width panel-tittle bg-primary  tittles'>
Descripcion
   </p>
   <strong>Nombre: </strong>  $nombre <br>
   <strong>Precio (Por Kilo): </strong>  $ $precio <br>
   <strong>Cantidad: </strong>  $cantidad Kilos<br>
   <strong>Valor Total: </strong>  $ $cantidad*$precio<br>
   <strong>Descripcion: </strong>   $des <br>

   <p class='full-width panel-tittle bg-primary  tittles'>
 Datos del Vendedor
   </p>



<strong>Nombre: </strong>  $nombre1 $apellido1<br>
<strong>Telefono: </strong>   $telefono<br>
<a  href='index.php?accion=inventario' class='btn btn-primary'>Regresar</a> ";


$salida1.=" 
<div class='mdl-grid'>
  <div class='mdl-cell mdl-cell--12-col'>
    <div class='full-width panel mdl-shadow--2dp'>
    <div class='full-width panel-tittle bg-primary text-center tittles'>
                  Actualizar Producto
    </div>
<div class='full-width panel-content'>
  <form  method='post' action='index.php?accion=actualizarproducto&id=$id' > 
                <div class='mdl-grid'>
										<div class='mdl-cell mdl-cell--12-col'>
									        <legend class='text-condensedLight'><i class='zmdi zmdi-border-color'></i> &nbsp; Informacion Basica</legend><br>
                    </div>
                     <div class='mdl-cell mdl-cell--12-col'>
                        <div class='mdl-textfield mdl-js-textfield'>
                            <select name='producto' class='mdl-textfield__input'  >
                               <option value='$id2'  selected=''>$id2 $nombre</option>";



                                              
                                                    foreach ($tablapro as $tabla) {
                                                    $valor=$tabla['Id'];
                                                    $valor1=$tabla['nombre'];
                                                    
                                                  $salida1.="<option value='$valor'>$valor $valor1</option>";

                                                    }
												

$salida1.="                	</select>
                        </div>
                      </div>
                      <div class='mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet'>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <label >Descripcion</label>
                        <input name='descripcion' class='mdl-textfield__input' type='text' pattern='-?[A-Za-z0-9áéíóúÁÉÍÓÚ ]*(\.[0-9]+)?' id='NameProduct'  value='$des'>
                          
                          <span class='mdl-textfield__error'>Descripcion</span>
                        </div>
                      </div>
                      <div class='mdl-cell mdl-cell--4-col mdl-cell--8-col-tablet'>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <label >Catidad por Kilos</label>
                          <input name='cantidad'class='mdl-textfield__input' type='number' pattern='-?[0-9]*(\.[0-9]+)?' id='StrockProduct' value='$cantidad' >
                        
                          <span class='mdl-textfield__error'>Numero Invalido</span>
                        </div>
                       </div>
                       <div class='mdl-cell mdl-cell--4-col mdl-cell--8-col-tablet'>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                      <label>Precio por Kilo </label>

												<input name='precio'class='mdl-textfield__input' type='number' pattern='-?[0-9]*(\.[0-9]+)?' id='PriceProduct' value='$precio'>
												<span class='mdl-textfield__error'>Precio Invalido</span>
											</div>
                    </div>
                    <div class='mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet'>
                      <div class='mdl-textfield mdl-js-textfield'>
                      <label>Estado</label>
												<select name='estado' class='mdl-textfield__input'>
													<option value='$num' selected=''' >$estado</option>
                          <option value='1' >Activo</option>
                          <option value='2'>En Cotizacion</option>
                          <option value='3'>Vendido</option>
                          
												
												</select>
											</div>
                    </div>
                    <div class='mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet'>
										<label >Fecha de Duracion de producto</label>
											<div class='mdl-textfield mdl-js-textfield'>

												<input type='date' class='mdl-textfield__input' name='fechafin' value='$fecha'>
												
											</div>
                    </div>
									
</div>
<p class='text-center'>
<button class='mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored bg-primary' id='btn-addProduct'>
  <i class='zmdi zmdi-plus'></i>
</button>


<button  onclick=this.form.action='index.php?accion=inventario' class='mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored bg-primary'>
<small><h6>Atras</h6></small>
  
</button>



</p>




</form>
</div>
</div>
</div>
</div>
";

echo $salida1;
$conexion->cerrar();
?>

