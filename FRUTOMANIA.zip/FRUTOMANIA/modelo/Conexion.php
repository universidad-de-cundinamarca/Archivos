<?php
class Conexion{

    private $conectar;
    private $sql;
    private $resultado;
    private $filas;

    public function abrir(){
        try{
        
      $this->conectar=new PDO('mysql:host=localhost; dbname=frutomania','root','');
       $this->conectar->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        
        }catch(Exception $e){
          die("Error " . $e->getMessage());
          echo "Linea del error: " . $e,getLine();
        
        
        }



}

public function cerrar(){
    $this->conectar=null;
    
    
    }


public function consulta($sql){
$this->sql=$sql;
$this->conectar->query($this->sql);
}
public function consulta1($sql){
  $this->sql=$sql;
  $this->result=$this->conectar->query($this->sql);

  $this->filas=$this->result->rowCount();
  }

public function obtenerResult(){
return $this->result;

}
public function obtenerFilasAfectadas(){
  return $this->filas;
  
  }
  


}


?>