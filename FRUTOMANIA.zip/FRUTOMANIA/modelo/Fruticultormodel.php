<?php
class Fruticultormodel{
    
    
public function producto(){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select * from producto";
$conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resul;
}

public function Registrarproducto($fechaini,$fechafin,$precio,$cantidad,$descripcion,$fruticultor,$fruta,$estado){
   
    $conexion=new Conexion();
    $conexion->abrir();

    $sql1="insert into producto_arriba values (null,'images.png','$fechaini','$fechafin',$precio,$cantidad,'$descripcion',$fruticultor,$fruta,$estado)";


$conexion->consulta($sql1);

$conexion->cerrar();

return 1;

}
public function Actualizarproducto($fechafin,$precio,$cantidad,$descripcion,$fruta,$estado,$id){
   
    $conexion=new Conexion();
    $conexion->abrir();

    $sql1="update  producto_arriba set fecha_fin='$fechafin', precio=$precio, cantidad=$cantidad,
    descripcion='$descripcion',fruta=$fruta, estado=$estado
    where id_arriba=$id";


$conexion->consulta($sql1);

$conexion->cerrar();

return 1;

}
public function Eliminarproducto($id){
   
    $conexion=new Conexion();
    $conexion->abrir();

    $sql1="delete from producto_arriba
    where id_arriba=$id";


$conexion->consulta($sql1);

$conexion->cerrar();

return 1;

}
public function productoarriba($ced){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select producto.*,producto_arriba.*from producto,producto_arriba where producto_arriba.fruticultor='$ced' AND  producto_arriba.fruta=producto.Id" ;
$conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resul;
}
public function productoarribacotizado($ced){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select producto_comerciante.*,producto_arriba.*,producto.*,persona.* 
    from producto_comerciante,producto_arriba,producto,persona
     where producto_comerciante.fruticultor='$ced' 
     and producto_arriba.fruticultor='$ced' 
     AND  producto_arriba.fruta=producto.Id 
     and ((producto_arriba.estado=2) or (producto_arriba.estado=4)) 
     and producto_arriba.id_arriba=producto_comerciante.producto  and comerciante=cedula
     and producto_comerciante.Estadocf=0 " ;
$conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resul;
}
public function productoarribacotizado1($ced){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select prevendidos.* ,persona.* from  prevendidos,persona
     where vendedor='$ced' 
     and cedula=prevendidos.cliente
     ORDER BY id_prevendidos DESC" ;
$conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resul;
}


public function productoarriba1(){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select producto.*,producto_arriba.* from producto,producto_arriba where  producto_arriba.fruta=producto.Id" ;
$conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resul;
}
public function productoarribatodo($id){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select producto.*,producto_arriba.*,persona.* from producto,producto_arriba,persona where  producto_arriba.fruta=producto.Id and producto_arriba.fruticultor=persona.cedula and producto_arriba.id_arriba=$id" ;
$conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resul;
}
}
?>