<?php
class cotizarmodelo{

public function recotizar($cliente,$producto,$fruti,$ofrece){

    $conexion=new Conexion();
    $conexion->abrir();
$mensaje="";
    $sql="insert into producto_comerciante values (null,$producto,$cliente,$fruti,'$mensaje',$ofrece,0)";
   $sql1="update producto_arriba set  estado=2, cantidad=0 where id_arriba=$producto";

   
    $conexion->consulta1($sql);
$resul=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   $conexion->abrir();
   $conexion->consulta1($sql1);
   $conexion->cerrar();
   return $resul;

}
public function recotizar1($cliente,$producto,$fruti,$ofrece,$ofrecerqueda){

    $conexion=new Conexion();
    $conexion->abrir();
$mensaje="";
    $sql="insert into producto_comerciante values (null,$producto,$cliente,$fruti,'$mensaje',$ofrece,0)";
   $sql1="update producto_arriba set  cantidad=$ofrecerqueda,estado=4  where id_arriba=$producto";

   
    $conexion->consulta1($sql);
$resul=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   $conexion->abrir();
   $conexion->consulta1($sql1);
   $conexion->cerrar();
   return $resul;

}
public function cotizaciones($ced){

    $conexion=new Conexion();
    $conexion->abrir();

    $sql="select producto_comerciante.*,producto_arriba.*,producto.*,persona.* 
    from producto_comerciante,producto_arriba,producto,persona 
    where producto_comerciante.comerciante='$ced'
    AND  producto_arriba.fruta=producto.Id  
    and producto_arriba.id_arriba=producto_comerciante.producto  
    and producto_arriba.fruticultor=cedula
    and producto_comerciante.Estadocf not in (4) " ;

  
    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function comprados($ced){

    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select prevendidos.* ,persona.* from  prevendidos,persona
    where cliente='$ced' 
    and cedula=prevendidos.vendedor
    ORDER BY id_prevendidos DESC;" ;
    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function campro($id){

    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select producto from producto_comerciante  where producto=$id" ;
    $conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
   $conexion->cerrar();
   return $resul;

}
public function cancelarcoti($id,$ida,$can){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="update  producto_arriba set estado=1, cantidad=$can where id_arriba=$ida" ;
    $sql1="delete from  producto_comerciante where id_productocomerciante=$id" ;
$conexion->consulta1($sql);
$conexion->consulta1($sql1);
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resultado;
}
public function cancelarco($id){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql1="delete from  producto_comerciante where id_productocomerciante=$id" ;

$conexion->consulta1($sql1);

   $conexion->cerrar();
  
}
public function cancelarco1($id){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql1="update  producto_comerciante set Estadocf=4 where id_productocomerciante=$id" ;

$conexion->consulta1($sql1);

   $conexion->cerrar();
  
}
public function cancelarcotiin($id,$can,$ida){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="update  producto_arriba set cantidad=$can where id_arriba=$ida" ;
    $sql1="delete from  producto_comerciante where id_productocomerciante=$id" ;
$conexion->consulta1($sql);
$conexion->consulta1($sql1);
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resultado;
}

public function cancelarcotiin1($id,$can,$ida,$etd){
 
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="update  producto_arriba set cantidad=$can, estado=$etd where id_arriba=$id" ;
    $sql1="update  producto_comerciante set  estadocf=1 where id_productocomerciante=$ida" ;
    
$conexion->consulta1($sql);
$conexion->consulta1($sql1);
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
return $resultado;
}
public function realizarcoti($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente){
 
    $conexion=new Conexion();
    $conexion->abrir();
  
    $sql="delete from producto_comerciante where id_productocomerciante=$id" ;
    $sql1="delete from producto_arriba where id_arriba=$ida";
    $sql2="insert into prevendidos values (null,'$nombre',$cantidad,$precio,'$vendedor','$cliente')";
$conexion->consulta1($sql);
$conexion->consulta1($sql1);
$conexion->consulta1($sql2);
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
return $resultado;
}
public function realizarcotiper($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente){
 
    $conexion=new Conexion();
    $conexion->abrir();
  
    $sql="delete from producto_comerciante where id_productocomerciante=$id" ;
    $sql1="update producto_arriba set cantidad=0, estado=2 where id_arriba=$ida";
    $sql2="insert into prevendidos values (null,'$nombre',$cantidad,$precio,'$vendedor','$cliente')";
$conexion->consulta1($sql);
$conexion->consulta1($sql1);
$conexion->consulta1($sql2);
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
return $resultado;
}
public function realizarcoti1($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente){
 
    $conexion=new Conexion();
    $conexion->abrir();
  
    $sql="delete from producto_comerciante where id_productocomerciante=$id";
    $sql1="update producto_arriba set estado=4 where id_arriba=$ida";
    $sql2="insert into prevendidos values (null,'$nombre',$cantidad,$precio,'$vendedor','$cliente')";
$conexion->consulta1($sql);
$conexion->consulta1($sql1);
$conexion->consulta1($sql2);
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
return $resultado;
}
public function realizarcotiper2($id,$ida,$nombre,$precio,$cantidad,$vendedor,$cliente){
 
    $conexion=new Conexion();
    $conexion->abrir();
  
    $sql="delete from producto_comerciante where id_productocomerciante=$id" ;
    $sql1="update producto_arriba set estado=1 where id_arriba=$ida";
    $sql2="insert into prevendidos values (null,'$nombre',$cantidad,$precio,'$vendedor','$cliente')";
$conexion->consulta1($sql);
$conexion->consulta1($sql1);
$conexion->consulta1($sql2);
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
return $resultado;
}

}


?>