<?php
	

    $salida = "";
   

    require_once 'Conexion.php';
    $conexion=new Conexion();
    $conexion->abrir();
    
    $query="select producto.*,producto_arriba.* from producto,producto_arriba where  producto_arriba.fruta=producto.Id and ((estado=1)or(estado=4))"  ;
    
    if (isset($_POST['consulta'])) {
        $q = $_POST['consulta'];
        $query="select producto.*,producto_arriba.* from producto,producto_arriba where  producto_arriba.fruta=producto.Id  and ((estado=1)or(estado=4)) AND nombre LIKE '%$q%'  "  ;
      
    }

    $conexion->consulta1($query);
    $resultado=$conexion->obtenerResult();
    $resul=$conexion->obtenerFilasAfectadas();
 

  
 
    

        $salida.="<div  class='mdl-grid' >";

        foreach ($resultado as $tabla) {
            $valor=$tabla['nombre'];
            $valor1=$tabla['precio'];
            $valor3=$tabla['cantidad'];
            $imagen=$tabla['imagen'];
            $valortotal=$valor1*$valor3;
            $valor5=$tabla['id_arriba'];
            $valor6=$tabla['Id'];
            $fruti=$tabla['fruticultor'];
            $numero = 15200.67;
            $valortotal=number_format($valortotal);
          
    	$salida.="
        <div class='mdl-card mdl-shadow--2dp mdl-cell mdl-cell--4-col mdl-cell--8-col-tablet'>
            <div class='mdl-card__title'>
            <a href='index.php?accion=verproducto&id=$valor5'>
        
                <img src='vista/imagenes/$valor.png' alt='product' class='img-responsive2'>
               
                </a>
            </div>
            <div class='mdl-card__supporting-text'>
                <strong> Cantidad: $valor3 (Kilos) </strong><br>
                <strong> Valor Kilo $ $valor1</strong	><br>
                <strong> Valor Total $valortotal</strong	>
                
            </div>
            <div class='mdl-card__actions mdl-card--border'>
            <form action='index.php?accion=cotizar&id=$valor5&ida=$valor6&cantidad=$valor3&fruti=$fruti&precio=$valor1' method='post'>
            $valor <input type='number' name='ofrecer' value='$valor3'   min='1' max='$valor3'>
            <button  title='Cotizar' style='color:black;'>
            <i class='zmdi zmdi-plus'></i>  
            </button>
            </form>
               
                
            </div>
            </div>
            ";
            

        }

        $salida.="		 
           </div>";
    	
    


    echo $salida;

    $conexion->cerrar();


//href='index.php?accion=cotizar&id=$valor5&nombre=$valor&cantidad=$valor3&valor=$valortotal'
?>
