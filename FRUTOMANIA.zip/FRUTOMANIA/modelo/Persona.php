<?php
class Persona{
    private $nombre;
    private $nombre1; 
private $apellido;
private $apellido1;
private $cedula;
private $telefono;
private $correo;
private $user;
private $password;
private $fecha;
private $id_usu;
private $estado;


public function __construct($nombre,$nombre1,$apellido,$apellido1,$cedula,$telefono,$correo,$user,$password,$fecha,$id_usu,$estado){
$this->nombre=$nombre;
$this->nombre1=$nombre1;
$this->apellido=$apellido;
$this->apellido1=$apellido1;
$this->cedula=$cedula;
$this->telefono=$telefono;
$this->correo=$correo;
$this->user=$user;
$this->password=$password;
$this->fecha=$fecha;
$this->id_usu=$id_usu;
$this->estado=$estado;


}

public function obtenerNombre(){
return $this->nombre;

}
public function obtenerNombre1(){
    return $this->nombre1;
    
    }

public function  obtenerApellido(){

    return $this->apellido;
}

public function  obtenerApellido1(){

    return $this->apellido1;
}

public function  obtenerCedula(){

    return $this->cedula;
}
public function obtenerTelefono (){

    return $this->telefono;
}
public function obtenerCorreo (){

    return $this->correo;
}
public function obtenerUser (){

    return $this->user;
}
public function obtenerPassword (){

    return $this->password;
}
public function obtenerFecha (){

    return $this->fecha;
}
public function obtenerIdUsu (){

    return $this->id_usu;
}
public function obtenerEstado (){

    return $this->estado;
}
}

?>