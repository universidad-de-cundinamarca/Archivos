<?php

class Sesion{

public function __construct(){

session_start();


}

public function setCurrent($usu){

    $_SESSION['usu']=$usu;
}
    
public function getCurrent(){
    return $_SESSION['usu'];
}

public function closeSesion(){
session_unset();
session_destroy();

}

}




?>