<?php
class GestionLogin{

public function RegistroUsuario(Persona $persona){
    $conexion=new Conexion();
    $conexion->abrir();
    $nombre=$persona->obtenerNombre();
    $nombre1=$persona->obtenerNombre1();
    $apellido=$persona->obtenerApellido();
    $apellido1=$persona->obtenerApellido1();
    $cedula=$persona->obtenerCedula();
    $telefono=$persona->obtenerTelefono();
    $correo=$persona->obtenerCorreo();
    $user=$persona->obtenerUser();
    $password=$persona->obtenerPassword();
    $fecha=$persona->obtenerFecha();
    $id_usu=$persona->obtenerIdUsu();
    $estado=$persona->obtenerEstado();
    $sql="insert into persona values (null,'$nombre','$nombre1','$apellido','$apellido1','$cedula','$telefono','$correo')";
    $sql1="insert into usuario values ('$user','$password','$fecha','$cedula','$id_usu','$estado')";

$conexion->consulta($sql1);
$conexion->cerrar();
$conexion->abrir();
$conexion->consulta($sql);

$conexion->cerrar();

return 1;
}

public function InicioSecion($usuario){
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select cedula,password,Id_usu from usuario where 
    (usuario.user='$usuario' OR usuario.cedula='$usuario')";
$conexion->consulta1($sql);
$resul=$conexion->obtenerResult();
$resultado=$conexion->obtenerFilasAfectadas();
   $conexion->cerrar();
   return $resul;

}

public function setUsuario($ced){
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select persona.*,usuario.* from persona,usuario where usuario.cedula='$ced' AND persona.cedula='$ced'";
    $conexion->consulta1($sql);
    $resultado=$conexion->obtenerResult();
    $conexion->cerrar();
    return $resultado;

}
public function persona(){
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select cedula from persona";
    $conexion->consulta1($sql);
    $resultado=$conexion->obtenerResult();
    $conexion->cerrar();
    return $resultado;

}
public function usuarios(){
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select Id_usu from usuario";
    $conexion->consulta1($sql);
    $resultado=$conexion->obtenerResult();
    $conexion->cerrar();
    return $resultado;

}
public function actualizarusu($ced){
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="select usuario.*,persona.* from usuario,persona where persona.cedula=$ced and usuario.cedula=persona.cedula";
    $conexion->consulta1($sql);
    $resultado=$conexion->obtenerResult();
    $conexion->cerrar();
    return $resultado;

}
public function reactualizacion($ced,$nom,$nom1,$ape,$ape1,$tel,$correo,$user,$pass){
    $conexion=new Conexion();
    $conexion->abrir();
    $sql="update persona set nombre1='$nom',nombre2='$nom1',apellido1='$ape',apellido2='$ape1',
    telefono='$tel',correo='$correo'
    where cedula='$ced'";
    $sql1="update usuario set user='$user',password='$pass' 
    where cedula='$ced'";

 
   $conexion->consulta1($sql);
    $conexion->consulta1($sql1);
    $resultado=$conexion->obtenerFilasAfectadas();
    $conexion->cerrar();
    return $resultado;

}


}



?>