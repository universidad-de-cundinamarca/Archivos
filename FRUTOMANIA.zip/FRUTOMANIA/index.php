<?php
 session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="vista/css/bootstrap.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
   <script src="vista/js/bootstrap.js" ></script>

   <script>
      $(document).ready(function()
      {
         $("#mostrarmodal").modal("show");
      });
    </script>
	
</head>

<body>

<?php
 require_once 'controlador/Controlador.php';
 require_once 'controlador/usuario.php';
 require_once 'controlador/Sesion1.php';

 require_once 'controlador/Fruticultor.php';
 require_once 'controlador/Cotizar.php';
 require_once 'modelo/GestionLogin.php';
 require_once 'modelo/Persona.php';
 require_once 'modelo/Conexion.php';
 require_once 'modelo/Sesion.php';
 require_once 'modelo/Admimodelo.php';
 require_once 'modelo/Fruticultormodel.php';
 require_once 'modelo/cotizarmodelo.php';
 $controlador=new Controlador();
 $sesion=new Sesion1();

$fruti=new Fruticultor();
$cotizar=new Cotizar();



if(isset($_GET['accion'])){

	if($_GET['accion']=="refresco"){
		echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=inicio'>";
	}

	if(isset($_SESSION['usu'])){


		$sesion->setUsuario($sesion->getCurrent());
	
		if($_GET['accion']=="actualizardatos"){

			$tablaactu=$controlador->actualizarusu($sesion->getCurrent());


			include_once ("vista/html/actualizaradmi.php");



			}
			if($_GET['accion']=="realiazaractualizacion"){

		         
				$res=$controlador->reactualizacion($_POST['cedula'],$_POST['nombre'],$_POST['nombre1'],$_POST['apellido'],$_POST['apellido1'],$_POST['telefono'],
				$_POST['correo'],$_POST['user'],$_POST['password']);

if($res==1){
	echo '<script>
	alert("");</script>';
}
else{
	echo '<script>
	alert("Actualizacion Exitosa");</script>';

	
}

include_once ("vista/html/home.php");



				}

	
		if($_GET['accion']=="quienes"){

		
			include_once "vista/html/quienessomos.php";


}

	

		if($_GET['accion']=="salir"){

		      $sesion->closeSesion();
			  $sesion->setRol(0);
				include_once ("vista/html/home.php");
				
		}
		elseif($_GET['accion']=="frutas"){
		
			$tablaprosubir=$fruti->productoarriba1();
			include_once "vista/html/frutas.php";
		}
		elseif($_GET['accion']=="inicio"){
		
			include_once "vista/html/home.php";

			}
			if($_GET['accion']=="cotizar"){
				$id=$_GET['id'];
				$cantidad=$_GET['cantidad'];
				$fruti=$_GET['fruti'];
				$ofrecer=$_POST['ofrecer'];
				$cliente=$sesion->getCedula();
				$precio=$_GET['precio'];
				$ida=$_GET['ida'];
				if($cantidad==$ofrecer){
					$res=0;

					if($sesion->getRol()==3){

						echo "<script>alert('No puedes ejecutar esta accion');</script>";	

					}else{
						$res=$cotizar->recotizar($cliente,$id,$fruti,$ofrecer);


					}

				 if($res==-1){
					echo "<script>alert('No se pueden cotizar tus mismos productos');</script>";	


				}

			if ($res>0) {
				echo "<script>alert('Cotizacion Existosa');</script>";
				
				echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=frutas'>";
			}
			else{

				echo "<script>alert('Algo a sucedido mal!');</script>";
				echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=frutas'>";
			}

				}
				else{
					$res=0;
					$ofrecerqueda=$cantidad-$ofrecer;

					if($sesion->getRol()==3){
						echo "<script>alert('No puedes ejecutar esta accion');</script> ";
						
					}else{
						$res=$cotizar->recotizar1($cliente,$id,$fruti,$ofrecer,$ofrecerqueda);



					}


					if($res==-1){
						echo "<script>alert('No se pueden cotizar tus mismos productos');</script>";	


					}


					if ($res>0) {
						echo "<script>alert('Cotizacion Existosa');</script>";
						
						echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=frutas'>";
					}
					if($res==0){
		
						echo "<script>alert('Algo a sucedido mal!');</script>";
						echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=inventario'>";
					}

				}
        
			//include_once "vista/html/cotizar.php";

			}



		
			elseif($_GET['accion']=="verproducto"){
				$tablaprosubir=$fruti->productoarribatodo($_GET['id']);



				include_once "vista/html/verproducto.php";
				
			}
			

				elseif($_GET['accion']=="cotizaciones"){

					$cliente=$sesion->getCedula();
					$tablacom=$cotizar->comprados($sesion->getCedula());
					$tablacotizacion=$cotizar->cotizaciones($cliente);
	
					include_once "vista/html/cotizar.php";
	
	
				}

	
				elseif($_GET['accion']=="cancelarcoti"){
					$tablacom=$cotizar->comprados($sesion->getCedula());
					$cliente=$sesion->getCedula();
					$tablacotizacion=$cotizar->cotizaciones($cliente);

				
					

					

						if($_GET['estado']==2){
							
							$res=$cotizar->cancelarcoti($_GET['id'],$_GET['ida'],$_GET['cantidad']);
							if($res>0){
								echo "<script>
								alert ('Cotizacion Cancelada');
								</script>";


							}else{
								echo "<script>
								alert ('Ocurrio un Error');
								</script>";
							}
							echo "<META HTTP-EQUIV='REFRESH' CONTENT='1;URL=index.php?accion=cotizaciones'>";

						
						}

						if($_GET['estado']==4){
							$res=$cotizar->cancelarcotiin($_GET['id'],$_GET['cantidad'],$_GET['ida']);
							if($res>0){
								echo "<script>
								alert ('Cotizacion Cancelada');
								</script>";


							}else{
								echo "<script>
								alert ('Ocurrio un Error');
								</script>";
							}
							echo "<META HTTP-EQUIV='REFRESH' CONTENT='1;URL=index.php?accion=cotizaciones'>";


						}
						
						if($_GET['estado']==1){
							$cotizar->cancelarco($_GET['id']);

							echo "<META HTTP-EQUIV='REFRESH' CONTENT='1;URL=index.php?accion=cotizaciones'>";

						}
						if($_GET['estado']==7){

							$cotizar->cancelarco1($_GET['id']);

							echo "<META HTTP-EQUIV='REFRESH' CONTENT='1;URL=index.php?accion=cotizaciones'>";

						}
						if($_GET['estado']==5){


							$res=$cotizar->cancelarcotiin1($_GET['id'],$_GET['cantidad'],$_GET['ida'],$_GET['etd']);
							if($res>0){
								echo "<script>
								alert ('Cotizacion Cancelada');
								</script>";


							}else{
								echo "<script>
								alert ('Ocurrio un Error');
								</script>";
							}
							echo "<META HTTP-EQUIV='REFRESH' CONTENT='1;URL=index.php?accion=inventario'>";


						}
						if($_GET['estado']==6){

							if($_GET['tar']=="true"){
								
								$res=$cotizar->realizarcoti($_GET['id'],$_GET['ida'],$_GET['nombre'],$_GET['precio'],$_GET['cantidad'],$_GET['vendedor'],$_GET['cliente']);
                            

							}
							else{
								$res=$cotizar->realizarcoti1($_GET['id'],$_GET['ida'],$_GET['nombre'],$_GET['precio'],$_GET['cantidad'],$_GET['vendedor'],$_GET['cliente']);
							}
							
							if($res>0){
								echo "<script>
								alert ('Pre Venta Existosa');
								</script>";


							}else{
								echo "<script>
								alert ('Ocurrio un Error');
								</script>";
							}
							echo "<META HTTP-EQUIV='REFRESH' CONTENT='1;URL=index.php?accion=inventario'>";


						}
					
	
	
					//include_once "vista/html/cotizar.php";
	
	
				}

		elseif($sesion->getRol()==2){
			
			$tablaproarriba=$fruti->productoarriba($sesion->getCedula());
			if($_GET['accion']=="inventario"){

				$tablaproarribacotizado=$fruti->productoarribacotizado($sesion->getCedula());

				$tablavendidos=$fruti->productoarribacotizado1($sesion->getCedula());
				
				$tablapro=$fruti->Producto();

				include_once "vista/html/inventario.php";
	
				}
				if($_GET['accion']=="agregarproductoinventario"){
					$tablapro=$fruti->Producto();
	
					include_once "vista/html/agregarproductoinventario.php";
		
					}

					if($_GET['accion']=="agregarproducto"){
						$fechaini=date('y-m-d',time());
						$fruticultor=$sesion->getCedula();
						
						$res=$fruti->Registrarproducto($fechaini, $_POST['fechafin'],$_POST['precio'],
						$_POST['cantidad'],$_POST['descripcion'],$fruticultor,$_POST['producto'],$_POST['estado']);
						
						
		if($res==1){
			echo '<script>
			alert("Registro Exitoso");</script>';
			$tablapro=$fruti->Producto();
		//include_once ("vista/html/inventario.php");
		echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=inventario'>";
			}  
			else {
			
				echo $res;
			
			} 
						}
						if($_GET['accion']=="actualizarproducto"){
							$res=$fruti->Actualizarproducto( $_POST['fechafin'],$_POST['precio'],
							$_POST['cantidad'],$_POST['descripcion'],$_POST['producto'],$_POST['estado'],$_GET['id']);
							if($res==1){
								echo '<script>
								alert("Actualizacion Exitosa");</script>';
								$tablapro=$fruti->Producto();
							//include_once ("vista/html/inventario.php");
							echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=inventario'>";
								}  
								else {
								
									echo $res;
								
								} 
						}
						if($_GET['accion']=="eliminarproducto"){
							 
							$res=$fruti->Eliminarproducto($_GET['id']);
							if($res==1){
								echo '<script>
								alert("Producto Eliminado");</script>';
								$tablapro=$fruti->Producto();
							//include_once ("vista/html/inventario.php");
							echo "<meta http-equiv='Refresh' content='0;url=index.php?accion=inventario'>";
								}  
								else {
								
									echo $res;
								
								} 


						}




		}
		elseif($sesion->getRol()==3 or $sesion->getRol()==4 ){
			$tablausu=$controlador->usuarios();
			
			$pro=$controlador->productos();


			if($_GET['accion']=="frutiadmi"){


			include_once ("vista/html/frutiadmi.php");

			}
			if($_GET['accion']=="actualizaradmi"){

				$tablaactu=$controlador->actualizarusu($_GET['id']);


				include_once ("vista/html/actualizaradmi.php");
	


				}

				if($_GET['accion']=="realiazaractualizacion"){

		         
					$res=$controlador->reactualizacion($_POST['cedula'],$_POST['nombre'],$_POST['nombre1'],$_POST['apellido'],$_POST['apellido1'],$_POST['telefono'],
					$_POST['correo'],$_POST['user'],$_POST['password']);
	if($res==1){
		echo '<script>
		alert("");</script>';
	}
	else{
		echo '<script>
		alert("Actualizacion Exitosa");</script>';

		
	}

	include_once ("vista/html/frutiadmi.php");


	
					}


				if($_GET['accion']=="cliente"){  
					include_once "vista/html/cliente.php";
				 }

				 if($_GET['accion']=="inventario"){  
					include_once "vista/html/frutas.php";
				 }
			
			
				 if($_GET['accion']=="fruticultor"){  
			
					include_once "vista/html/fruticultor.php";
					
				 }

				 if($_GET['accion']=="registrar"){  
		 
					$fecha=date('y-m-d',time());
			
					$res=$controlador->Registrar($_POST['nombre'],$_POST['nombre1'],$_POST['apellido'],$_POST['apellido1'],$_POST['cedula'],$_POST['telefono'],
					$_POST['correo'],$_POST['user'],$_POST['password'],$fecha,1);
			
					if($res==-1){
			
						echo '<div class="modal fade" id="mostrarmodal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
							 <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
								<h3>Error de Registro 4545</h3>
							 </div>
							 <div class="modal-body">
								<h4>Error</h4>
							Cedula Ya existe     
						 </div>
							 <div class="modal-footer">
							<a href="index.php?accion=cliente" data-dismiss="modal" class="btn btn-danger">Cerrar</a>
							 </div>
						</div>
					 </div>
					</div>
						
					';
					
					}
					
			
			
					if($res==1){
						echo '<script>
						alert("Registro Exitoso");</script>';
						include_once ("vista/html/frutiadmi.php");
						}  
						else {
						
							include_once ("vista/html/cliente.php");
						
						} 
					
					}
					
					if($_GET['accion']=="registrarfruti"){  
			
			
						$fecha=date('y-m-d',time());
				
						$res=$controlador->Registrar($_POST['nombre'],$_POST['nombre1'],$_POST['apellido'],$_POST['apellido1'],$_POST['cedula'],$_POST['telefono'],
						$_POST['correo'],$_POST['user'],$_POST['password'],$fecha,2);
						
						if($res==-1){
			
							echo '<div class="modal fade" id="mostrarmodal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
								 <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h3>Error de Registro 4545</h3>
								 </div>
								 <div class="modal-body">
									<h4>Error</h4>
								Cedula Ya existe     
							 </div>
								 <div class="modal-footer">
								<a href="index.php?accion=fruticultor" data-dismiss="modal" class="btn btn-danger">Cerrar</a>
								 </div>
							</div>
						 </div>
						</div>
							
						';
						
						}
						if($res==1){
							echo '<script>
							alert("Registro Exitoso");</script>';
							include_once ("vista/html/frutiadmi.php");
							}  
							else {
								include_once ("vista/html/fruticultor.php");
							
							} 
						
						}






				 if($sesion->getRol()==3) {


				 if($_GET['accion']=="administrador"){  
			
					include_once "vista/html/administrador.php";
					
				 }

				
				 if($_GET['accion']=="registraradmi"){  
			
					$fecha=date('y-m-d',time());
	
					$res=$controlador->Registrar($_POST['nombre'],$_POST['nombre1'],$_POST['apellido'],$_POST['apellido1'],$_POST['cedula'],$_POST['telefono'],
					$_POST['correo'],$_POST['user'],$_POST['password'],$fecha,4);
					
					if($res==-1){
		
						echo '<div class="modal fade" id="mostrarmodal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
							 <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
								<h3>Error de Registro 4545</h3>
							 </div>
							 <div class="modal-body">
								<h4>Error</h4>
							Cedula Ya existe     
						 </div>
							 <div class="modal-footer">
							<a href="index.php?accion=administrador" data-dismiss="modal" class="btn btn-danger">Cerrar</a>
							 </div>
						</div>
					 </div>
					</div>
						
					';
					
					}
					if($res==1){
						echo '<script>
						alert("Registro Exitoso");</script>';
						include_once ("vista/html/frutiadmi.php");
						}  
						else {
							include_once ("vista/html/administrador.php");
						
						} 
					
					}
				}
				
				}
					
					
		


	}
	else{

		if($_GET['accion']=="quienes"){

		
			 include_once "vista/html/quienessomos.php";
 
 
 }

		if($_GET['accion']=="cotizar"){

		 echo "<script> alert('Primero debes Registrarte');  </script>";
			include_once "vista/html/frutas.php";


}

if($_GET['accion']=="cotizaciones"){


	 include_once "vista/html/frutas.php";


}
if($_GET['accion']=="verproducto"){

	echo "<script> alert('Primero debes Registrarte');  </script>";
	   include_once "vista/html/frutas.php";


}

		if($_GET['accion']=="registro"){

			include_once "vista/html/Registro.php";
		}
		

		if($_GET['accion']=="frutas"){
			$tablaprosubir=$fruti->productoarriba1();
			include_once "vista/html/frutas.php";
		}
		if($_GET['accion']=="inicio"){
		
			include_once "vista/html/home.php";

			}
			if($_GET['accion']=="iniciosesion"){
		
				include_once "vista/html/Registro.php";
	
				}
				if($_GET['accion']=="ingresar"){

					
		
				    if(isset($_POST['cedula']) && isset($_POST['contraseña'])){
                        
                        
                        $usu=$_POST['cedula'];
												$pass=$_POST['contraseña'];
										
                    
                        if($controlador->InicioSecion($usu,$pass)=="cliente"){
							
                            $sesion->setUsuario($usu);

                            $sesion->setCurrent($usu);
                            
                            include_once "vista/html/frutas.php";
                
}



elseif($controlador->InicioSecion($usu,$pass)=="fruticultor"){

    $sesion->setUsuario($usu);

	$sesion->setCurrent($usu);
	$tablaproarribacotizado=$fruti->productoarribacotizado($sesion->getCedula());
	$tablaproarriba=$fruti->productoarriba($sesion->getCedula());
	$tablapro=$fruti->Producto();
    include_once  ("vista/html/inventario.php");
}

elseif($controlador->InicioSecion($usu,$pass)=="administrador" ){

    $sesion->setUsuario($usu);

    $sesion->setCurrent($usu);

    include_once  ("vista/html/home.php");
}
else{
    include_once ("vista/html/Registro.php");
echo '<script>
alert("Datos Incorrectos");</script>';

} 



		
					}



	}


	if($_GET['accion']=="cliente"){  
		include_once "vista/html/cliente.php";
	 }

	 if($_GET['accion']=="fruticultor"){  

		include_once "vista/html/fruticultor.php";
		
	 }
	 if($_GET['accion']=="registrar"){  
		 
		$fecha=date('y-m-d',time());

		$res=$controlador->Registrar($_POST['nombre'],$_POST['nombre1'],$_POST['apellido'],$_POST['apellido1'],$_POST['cedula'],$_POST['telefono'],
		$_POST['correo'],$_POST['user'],$_POST['password'],$fecha,1);

		if($res==-1){

			echo '<div class="modal fade" id="mostrarmodal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
			<div class="modal-dialog">
			  <div class="modal-content">
				 <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h3>Error de Registro 4545</h3>
				 </div>
				 <div class="modal-body">
					<h4>Error</h4>
				Cedula Ya existe     
			 </div>
				 <div class="modal-footer">
				<a href="index.php?accion=cliente" data-dismiss="modal" class="btn btn-danger">Cerrar</a>
				 </div>
			</div>
		 </div>
	  </div>
		  
		';
		
		}
		


		if($res==1){
			echo '<script>
			alert("Registro Exitoso");</script>';
			include_once ("vista/html/Registro.php");
			}  
			else {
			
				include_once ("vista/html/cliente.php");
			
			} 
		
		}
		
		if($_GET['accion']=="registrarfruti"){  


			$fecha=date('y-m-d',time());
	
			$res=$controlador->Registrar($_POST['nombre'],$_POST['nombre1'],$_POST['apellido'],$_POST['apellido1'],$_POST['cedula'],$_POST['telefono'],
			$_POST['correo'],$_POST['user'],$_POST['password'],$fecha,2);
			
			if($res==-1){

				echo '<div class="modal fade" id="mostrarmodal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
				<div class="modal-dialog">
				  <div class="modal-content">
					 <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h3>Error de Registro 4545</h3>
					 </div>
					 <div class="modal-body">
						<h4>Error</h4>
					Cedula Ya existe     
				 </div>
					 <div class="modal-footer">
					<a href="index.php?accion=cliente" data-dismiss="modal" class="btn btn-danger">Cerrar</a>
					 </div>
				</div>
			 </div>
		  </div>
			  
			';
			
			}
			if($res==1){
				echo '<script>
				alert("Registro Exitoso");</script>';
				include_once ("vista/html/Registro.php");
				}  
				else {
					include_once ("vista/html/fruticultor.php");
				
				} 
			
			}
		
		}
	 }


	

else{
	
	if(isset($_SESSION['usu'])){

		$sesion->setUsuario($sesion->getCurrent());
		include_once "vista/html/home.php";
	
	}else

include_once "vista/html/home.php";
	
	
}


?>



</body>

</html>